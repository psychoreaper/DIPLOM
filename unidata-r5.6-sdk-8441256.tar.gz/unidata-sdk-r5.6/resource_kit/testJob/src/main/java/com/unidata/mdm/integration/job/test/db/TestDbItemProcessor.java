package com.unidata.mdm.integration.job.test.db;

import java.util.Date;

import org.springframework.batch.item.ItemProcessor;

/**
 * Items batch processor.
 */
public class TestDbItemProcessor implements ItemProcessor<TestDbItem, TestDbItem> {

    @Override
    public TestDbItem process(final TestDbItem item) {
        return new TestDbItem(item.getId(), new Date());
    }
}
