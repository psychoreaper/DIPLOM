package com.unidata.mdm.integration.job.test;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

public class TestItemWriter implements ItemWriter<TestProcessedItem> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TestItemWriter.class);

    @Override
    public void write(List<? extends TestProcessedItem> items) {
        StringBuilder builder = new StringBuilder("Write items [");

        builder.append("size=").append(items.size()).append(", values=[");

        String joined = items.stream().map(TestProcessedItem::getValue).collect(Collectors.joining(", "));

        builder.append(joined).append("]]");

        LOGGER.info(builder.toString());
    }

}
