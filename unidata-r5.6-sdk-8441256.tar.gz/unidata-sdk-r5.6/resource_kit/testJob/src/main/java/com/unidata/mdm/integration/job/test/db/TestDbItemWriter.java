package com.unidata.mdm.integration.job.test.db;

import java.util.HashMap;
import javax.sql.DataSource;

import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

/**
 * Batch write processed items to database.
 */
public class TestDbItemWriter extends JdbcBatchItemWriter<TestDbItem> {

    @Autowired
    public TestDbItemWriter(final DataSource dataSource) {
        setDataSource(dataSource);
        setSql("UPDATE etalons SET update_date = :update_date WHERE id = :id::uuid");
        setItemSqlParameterSourceProvider(item ->
                new MapSqlParameterSource(
                        new HashMap<String, Object>() {{
                            put("id", item.getId());
                            put("update_date", item.getUpdateDate());
                        }}
                )
        );
    }
}
