package com.unidata.mdm.integration.job.test;

public class TestProcessedItem {

    private String value;

    public TestProcessedItem() {
        // No-op.
    }

    public TestProcessedItem(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
