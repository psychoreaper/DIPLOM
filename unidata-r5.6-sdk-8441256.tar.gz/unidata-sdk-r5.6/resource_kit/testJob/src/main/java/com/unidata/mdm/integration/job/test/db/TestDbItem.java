package com.unidata.mdm.integration.job.test.db;

import java.util.Date;

/**
 * Item for batch processing.
 */
public class TestDbItem {

    private final String id;

    private final Date updateDate;

    public TestDbItem(final String id, final Date updateDate) {
        this.id = id;
        this.updateDate = updateDate;
    }

    public String getId() {
        return id;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
}
