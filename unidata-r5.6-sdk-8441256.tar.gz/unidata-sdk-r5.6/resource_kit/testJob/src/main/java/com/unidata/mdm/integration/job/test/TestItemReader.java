package com.unidata.mdm.integration.job.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;

public class TestItemReader implements ItemReader<TestItemSubmission> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TestItemReader.class);

    private Integer from;

    private Integer to;

    private Integer currentCount;

    private String firstParameter;

    public void setTo(Integer to) {
        this.to = to;
    }

    public void setFrom(Integer from) {
        this.from = from;
    }

    public void setFirstParameter(String firstParameter) {
        this.firstParameter = firstParameter;
    }

    @Override
    public TestItemSubmission read() {
        if (from == null || to == null) {
            LOGGER.error("Failed to get valid initializations");

            return null;
        }

        if (currentCount == null) {
            currentCount = from;
        }

        LOGGER.info("Reader [currentCount={}, from={}, to={}, firstParameter={}]", currentCount, from, to,
                firstParameter);

        TestItemSubmission result = null;

        if (currentCount <= to) {
            result = new TestItemSubmission("" + currentCount);
            currentCount++;
        }

        return result;
    }

}
