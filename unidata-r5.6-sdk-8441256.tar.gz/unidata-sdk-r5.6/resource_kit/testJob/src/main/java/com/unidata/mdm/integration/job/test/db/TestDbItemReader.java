package com.unidata.mdm.integration.job.test.db;

import javax.sql.DataSource;

import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Read items from database for job processing.
 */
public class TestDbItemReader extends JdbcCursorItemReader<TestDbItem> {

    @Autowired
    public TestDbItemReader(final DataSource dataSource) {
        setDataSource(dataSource);
        setSql("SELECT id, update_date FROM etalons");
        setRowMapper((rs, rowNum) ->
                new TestDbItem(rs.getString("id"), rs.getDate("update_date"))
        );
    }
}
