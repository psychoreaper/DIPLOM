package com.unidata.mdm.integration.job.test;

public class TestItemSubmission {

    private String value;

    public TestItemSubmission() {
        // No-op.
    }

    public TestItemSubmission(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
