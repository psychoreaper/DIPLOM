package com.unidata.mdm.integration.job.test;

import org.springframework.batch.item.ItemProcessor;

public class TestItemProcessor implements ItemProcessor<TestItemSubmission, TestProcessedItem> {

    @Override
    public TestProcessedItem process(TestItemSubmission item) throws Exception {
        return new TestProcessedItem(item.getValue());
    }

}
