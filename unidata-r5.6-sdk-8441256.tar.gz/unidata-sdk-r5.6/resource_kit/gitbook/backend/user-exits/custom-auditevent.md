# 1 Поддержка кастомизации существующих AuditEvent

> Сложность реализации: низкая.

Добавлена возможность создавать пользовательские расширения для системных событий аудита. Пользовательская кастомизация позволяет расширять системные события дополнительными полями или блокировать запись системных событий.

Для добавления нового UE реализуйте интерфейс:

```
com.unidata.mdm.backend.common.integration.exits.AfterAuditListener
```

В котором переопределите методы:

```
boolean beforeSave(List<String> customAuditUsableFields, BiConsumer<String, String> putUserDefinedData, Object... input)
```

* Если необходимо блокировать запись, то метод должен возвращать false.
* Если такой необходимости нет, то метод должен возвращать true.

Для записи кастомного поля необходимо вызвать метод accept у putUserDefinedData, в который первым параметром передать название поля \(список названий всех кастомных полей хранится в customUsableFields\), а вторым – значение, которое необходимо в это поле записать.

В файле unidata-conf.xml в секции &lt;conf:audit&gt; пропишите класс пользовательского расширения.

```
<conf:exits>
        <conf:listeners>
            <conf:listeners class="com.unidata.mdm.backend.service.audit.actions.impl.listener.реализация_AuditActionListener" id="id_совпадающий_с_id_системного_события"/>
        </conf:listeners>
        <conf:audit>
             ...
            <conf:beforeSave>
                  <conf:listenerRef listener="id_совпадающий_с_id_системного_события" entity="id_совпадающий_с_id_системного_события"/>
            </conf:beforeSave>
            ...
        </conf:audit>
</conf:exits>
```

## Тестовый пример

В примере реализовано расширение лога события **ImportOperationDataAuditAction **для определенного в backend.properties поля full\_name.

Способ проверки примера:

* В файл &lt;UNIDATA\_CONF\_DIR&gt;/backend.properties добавьте параметр:

```
unidata.audit.user.defined.columns=full_name
```

Добавьте файл ImportDataAuditActionListener.java в каталог backend/src/main/java/com/unidata/mdm/backend/service/audit/actions/impl/listener

См. файл **src/main/java/com/unidata/mdm/backend/service/audit/actions/impl/listener/ImportDataAuditActionListener.java**

