# Workflow
Юнидата использует для организации процессов согласования Activiti engine, составную часть платформы Альфреско. Больше об особенностях реализации BPMN 2.0 в Activiti можно узнать на [сайте](https://www.activiti.org/userguide/index.html) Activiti. Юнидата позволяет сконфигурировать и опубликовать бизнес процесс Activiti, который оформляется, как стандартный BPMN 2.0 XML файл. Создать и отредактировать такой файл можно, например, в платформе Эклипс или другом BPMN редакторе. Для того чтобы опубликовать процесс в Юнидате, нужно добавить конфигурацию процесса в файл `unidata-conf.xml`:



```XML
<?xml version="1.0" encoding="UTF-8"?>
<conf:configuration xmlns:conf="http://conf.mdm.unidata.com/"
                    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                    xsi:schemaLocation="http://conf.mdm.unidata.com/">
    ...
    <!-- Блок бизнес-процессов и воркфлоу верхнего уровня -->
    <conf:workflow>
        <!-- Блок относящийся непосредственно к бизнес-процессам -->
        <conf:processes>
            <!-- Блок конкретного процесса -->
            <conf:process id="approvalProcess"
                type="RecordEdit"
                name="Стандартный бизнес-процесс подтверждения изменений записи"
                path="wf/record-change-approval.bpmn20.xml"
                class="com.unidata.mdm.backend.service.wf.standard.StandardRecordApprovalProcessSupport" />
        </conf:processes>
    </conf:workflow>
    ...
</conf:configuration>
```


1. В данный момент поддерживаются четыре типа процессов (WorkflowProcessType, поле `type` в конфигурации процесса) - `RECORD_EDIT("RecordEdit"), RECORD_DELETE("RecordDelete"), RECORD_RESTORE("RecordRestore"), RECORD_MERGE("RecordMerge")`.
2. Поле `id` должно совпадать с именем процесса в BPMN. Будет использоваться, как processDefinitionId в Activiti.
3. Поле `name` содержит описание процессса.
4. Поле `path` содержит содержит путь к файлу описания процесса, доступныому через поиск в classpath.
5. Поле `class` определяет класс, имплементирующий интерфейс com.unidata.mdm.backend.common.integration.wf.WorkflowProcessSupport, который будет вызываться в разные моменты жизненного цикла процесса.
