# Пользовательские расширения

Пакеты расширений размещаются в каталоге &lt;CATALINA\_HOME&gt;/unidata-integration. Каталог сконфигурирован как виртуальный загрузчик пользовательских расширений при помощи файла context.xml.

Учетная запись пользователя ОС, используемая для запуска Tomcat, должна иметь полный доступ к каталогу &lt;CATALINA\_HOME&gt;/unidata-integration.

**Примечание**

Примеры кастомизации содержат отсылки на файлы пользовательских классов с комментариями. Примеры классов см. в каталоге unidata-resource-kit/testUserExits/src/... \(далее - src/...\)

## Установка

Скопируйте в каталог &lt;CATALINA\_HOME&gt;/unidata-integration JAR-файл с пакетом расширений. Причем, пакеты расширений копируются для каждого узла кластера. После завершения копирования перезапустите Tomcat. Загрузка интерфейсов производится автоматически во время запуска приложения.

Для интерфейсов из пакета com.unidata.mdm.integration.auth требуется дополнительно указать процедуры авторизации во внешних системах разграничения прав доступа в его XML-конфигурации.

При установке пакета расширений необходимо добавить описание о нем в файл &lt;TOMCAT\_HOME&gt;/conf/unidata/unidata-conf.xml. Пример описания интерфейса SecurityInterceptionProvider:

```
<conf:securityInterceptionProviders>
    <conf:provider id="standardSecurityInterceptionProvider"
       class="com.unidata.mdm.backend.service.security.impl.StandardSecurityInterceptionProvider"/>
</conf:securityInterceptionProviders>
```

## Удаление

Для удаления пакета расширений необходимо удалить соответствующий JAR-файл из каталога &lt;CATALINA\_HOME&gt;/unidata-integration. При использовании кластерной конфигурации файл необходимо удалить на всех узлах кластера.

При удалении нестандартных пакетов расширений необходимо удалить их описание из файла &lt;TOMCAT\_HOME&gt;/conf/unidata/unidata-conf.xml.

