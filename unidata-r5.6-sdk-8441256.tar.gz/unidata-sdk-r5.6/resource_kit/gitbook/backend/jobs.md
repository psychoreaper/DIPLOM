# Служебные задачи \(Jobs\)

============

### RU

##### Проект-пример: testJob

Инфраструктура задач основана на фреймворке spring batch. Более подробнее о нем: [https://projects.spring.io/spring-batch/](https://projects.spring.io/spring-batch/)

Для создания своей задачи нужно выполнить несколько шагов:

* определить [xml конфигурацию spring](./testJob/src/main/resources/com/unidata/mdm/integration/job/test/test-job.xml) for it
* упаковать конфигурацинный файл и классы в jar файл, путь и имя файла должно соответствовать маске com/unidata/mdm/integration/job/_\*/_-job.xml
* скопировать это jar в директорию unidata-integration
* сконфигурировать задачу в пользовательском интерфейсе приложения Unidata

Проект примера содержит две задачи:

* Первая генерирует данные и логирует их
* Вторая читает их из базы, обновляет и сохраняет обратно

### EN

##### Sample project: testJob

Jobs infrastructure based on spring batch project. See: [https://projects.spring.io/spring-batch/](https://projects.spring.io/spring-batch/)

For creating your own job you need make some steps:

* define [spring configuration](./testJob/src/main/resources/com/unidata/mdm/integration/job/test/test-job.xml) for it
* pack configuration file and classes in jar archive, path and file should match to mask com/unidata/mdm/integration/job/_\*/_-job.xml
* place this jar in unidata-integration directory
* configure you job in UI of Unidata application

There are two sample job in testJob project:

* Fist generate items\(com.unidata.mdm.integration.job.test\)
* Second read data from data base, update date of record and save it in database\(com.unidata.mdm.integration.job.test.db\)



