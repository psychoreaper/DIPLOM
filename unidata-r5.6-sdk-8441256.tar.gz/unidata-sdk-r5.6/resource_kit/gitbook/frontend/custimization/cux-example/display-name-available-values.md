# Допустимые значения для атрибута "Отображаемое имя

Данные расширения позволяют установить в формах редактирования допустимые значения для атрибута "Отображаемое имя".


Все расширения имеют:

1) строковый массив availableDisplayNames - содержит допустимые значения для поля DislpayName.

2) и метод getAvailableDisplayNames - возвращающий массив допустимых значений.


Если метод  getAvailableDisplayNames возвращает массив со значениями, в формах отображается выпадающий список с допустимыми значениями.

Если метод getAvailableDisplayNames возвращает пустой массив, или null, или false - отображается текстовый инпут.


Отличаются расширения только параметрами, которые принимает метод getAvailableDisplayNames.


Примеры реализации:


Редактор классификатора, свойства - **CUX/override/uiuserexit/overridable/classifier/ClassifierEditor**

Редактор классификатора, свойства узлов - **CUX/override/uiuserexit/overridable/classifier/ClassifierNodeProperty.js**

Редактор классификатора, атрибуты узлов - **CUX/override/uiuserexit/overridable/classifier/ClassifierAttributeProperty.js**

Редактор реестров, свойства - **CUX/override/uiuserexit/overridable/entity/MetarecordProperty.js**

Редактор реестров, атрибуты - **CUX/override/uiuserexit/overridable/entity/MetarecordAttribute.js**

Редактор реестров, связи - **CUX/override/uiuserexit/overridable/entity/MetarecordRelation.js**
