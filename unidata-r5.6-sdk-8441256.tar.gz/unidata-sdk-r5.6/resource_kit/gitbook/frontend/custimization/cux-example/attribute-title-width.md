# Задание ширины лейбла атрибутов

Для указания ширины лейбла для атрибутов классификатора можно использовать css: 

```css
.un-dataentity-classifier-attribute .un-dataentity-attribute-title {
    width: 220px !important;
}
```

Для указания ширины лейбла для атрибутов на карточке записи можно использовать css:

```css
.un-dataentity-attribute-title {
    width: 220px !important;
}
```
