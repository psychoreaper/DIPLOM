## 23 Настройка таймаута ajax запросов

См. пример в файле **\ui-customization-tutorial\CUX\AjaxTimeout.js**
