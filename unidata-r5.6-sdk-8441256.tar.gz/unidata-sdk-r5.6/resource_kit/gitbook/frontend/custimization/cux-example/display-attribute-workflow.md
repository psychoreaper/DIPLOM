# 12 Настройка отображаемых атрибутов в списке заявок

> Сложность реализации: средняя.

Добавлена возможность скрытия лишних полей в поисковых выдачах в разделе "Задачи".

Чтобы скрыть атрибуты необходимо добавить их ключи в массивы taskHiddenAttributes и processHiddenAttributes.

* Массив **taskHiddenAttributes **скрывает атрибуты поисковой выдачи для задач.
* Массив **processHiddenAttributes **скрывает атрибуты поисковой выдачи для процессов.

Коды аттрибутов для задач \(**taskHiddenAttributes**\):

* taskTitle - Заголовок задачи
* taskId - ID задачи
* recordTitle - Имя записи
* entityTypeTitle - Имя реестра/справочника
* createDate - Дата назначения задачи

Коды аттрибутов для процессов \(**processHiddenAttributes**\):

* processTitle- Имя процесса
* processId- ID процесса
* processTypeName - Тип процесса
* recordTitle - Имя записи
* entityTypeTitle - Имя реестра / справочника
* createDate - Дата создания процесса

См. пример в файле **CUX/override/uiuserexit/overridable/workflow/tasksearch/Resultset.js**.

