gitbook pdf ./ ../gitbook.pdf

read -p "Press enter to continue"