package com.unidata.mdm.custom.wf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.unidata.mdm.backend.common.integration.wf.WorkflowAction;
import com.unidata.mdm.backend.common.integration.wf.WorkflowProcessEndState;
import com.unidata.mdm.backend.common.integration.wf.WorkflowProcessStartState;
import com.unidata.mdm.backend.common.integration.wf.WorkflowProcessSupport;
import com.unidata.mdm.backend.common.integration.wf.WorkflowTaskCompleteState;
import com.unidata.mdm.backend.common.integration.wf.WorkflowTaskGate;
import com.unidata.mdm.backend.common.integration.wf.WorkflowVariables;
import com.unidata.mdm.backend.common.security.SecurityToken;
import com.unidata.mdm.backend.common.service.ServiceUtils;
/**
 * @author Mikhail Mikhailov
 * The class implements {@link com.unidata.mdm.backend.common.integration.wf.WorkflowProcessSupport} and is used mainly as a process and process' task gate.
 * This can also be used to define global process variables at process start, or task variables at task processing time.
 */
public class TestCustomerWorkflowSupport implements WorkflowTaskGate, WorkflowProcessSupport {
    /**
     * Logger, as usually.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(TestCustomerWorkflowSupport.class);
    /**
     * Unidata uses 'task assignee candidate' concept, that is, the task is first assigned to a candidate group, and is then taken by concrete assignee for execution.
     * The name is basically a Unidata security role name.
     * So if you have, let's say, a role "approvingRole1", you define "approvingRole1" as the candidate group in your process definition.
     * It will be resolved to list of user names later on to identify users, suitable for step completion.
     */
    private static final String ROLE2_AS = "VAR_ROLE2_APPROVAL_STATE";
    /**
     * See above.
     */
    private static final String ROLE3_AS = "VAR_ROLE3_APPROVAL_STATE";

    /**
     * Default actions for delete approval
     */
    @SuppressWarnings("serial")
    private List<WorkflowAction> deleteActions = new ArrayList<WorkflowAction>(2) {
        {
            add(new WorkflowAction("ALLOW", "Разрешить", "Разрешить удаление ?"));
            add(new WorkflowAction("DENY", "Запретить", "Запретить удаление ?"));
        }
    };

    /**
     * Default actions for changes approval - zero level
     */
    @SuppressWarnings("serial")
    private List<WorkflowAction> zeroLevelApproveActions = new ArrayList<WorkflowAction>(3) {
        {
            add(new WorkflowAction("COMMIT", "Отправить на согласование", "Отправить на согласование ?"));
            add(new WorkflowAction("CANCEL", "Отменить", "Отменить изменения ?"));
        }
    };

    /**
     * Default actions for changes approval - first & second levels
     */
    @SuppressWarnings("serial")
    private List<WorkflowAction> approveActions = new ArrayList<WorkflowAction>(3) {
        {
            add(new WorkflowAction("COMMIT", "Согласовать", "Согласовать изменения ?"));
            add(new WorkflowAction("RETURN", "Вернуть", "Вернуть на доработку ?"));
            add(new WorkflowAction("CANCEL", "Отклонить", "Отклонить изменения ?"));
        }
    };

    /**
     * Gets actions, supported by the task with taskDefinitionId.
     * Those actions are displayed in UI task area.
     * {@link WorkflowAction#getCode()} is the action ID, which is selected by the user upon task completion and supplied to
     * {@link #complete(String, Map, String)}
     */
    @Override
    public List<WorkflowAction> getActions(String taskDefinitionId, Map<String, Object> variables) {

        LOGGER.info(String.format("Returning actions list for task %s", taskDefinitionId));

        if (taskDefinitionId.equals("deleteApprove")) {
            return deleteActions;
        }

        if (taskDefinitionId.equals("zeroLevelChangesApprove")) {
            return zeroLevelApproveActions;
        } else if (taskDefinitionId.contains("LevelChangesApproveRole")) {
            return approveActions;
        }

        return Collections.emptyList();
    }

    /**
     * Method called upon completion of a task.
     * If {@link WorkflowTaskCompleteState#isComplete()} return true, task completes successfully.
     * Task is not completed otherise.
     * @param taskDefinitionId the task id, as defined in BPMN model
     * @param variables combined process and task variables
     * @param actionCode the code of the action, selected by the user
     */
    @Override
    public WorkflowTaskCompleteState complete(String taskDefinitionId, Map<String, Object> variables, String actionCode) {

        LOGGER.info(String.format("Completing task %s with action %s", taskDefinitionId, actionCode));

        /*
         * Example: save task action codes for each parallel task
         */
        if (taskDefinitionId.equals("secondLevelChangesApproveRole2")) {
            variables.put(ROLE2_AS, actionCode);
        }

        if (taskDefinitionId.equals("secondLevelChangesApproveRole3")) {
            variables.put(ROLE3_AS, actionCode);
        }

        return new WorkflowTaskCompleteState(true, "Task completed");

    }

    /**
     * Executed upon process start.
     * Returns state as {@link WorkflowProcessStartState} object.
     * If {@link WorkflowProcessStartState#isAllowed()} returns {@code true}, the process starts.
     * The proces does not start otherwise.
     * @param processDefinitionId the process definition ID, as defined in BPMN and saved in Activiti engine
     * @param variables process variables, defined in BPMN
     */
    @Override
    public WorkflowProcessStartState processStart(String processDefinitionId, Map<String, Object> variables) {

        WorkflowProcessStartState state = new WorkflowProcessStartState(true, "");
        /*
         * As an example, set up some additional variables, which will be added to the process.
         * Here, some steps can be skipped, if the user has MY_TEST_ROLE_1 and MY_TEST_ROLE_2 roles.
         */
        Map<String, Object> additionalProcessVariables = new HashMap<>();
        SecurityToken token = ServiceUtils
                .getSecurityService()
                .getTokenObjectByToken(ServiceUtils.getSecurityService().getCurrentUserToken());

        Boolean skipStep1 = token.hasRole("MY_TEST_ROLE_1");
        Boolean skipStep2 = token.hasRole("MY_TEST_ROLE_2");

        additionalProcessVariables.put("skipStep1", skipStep1);
        additionalProcessVariables.put("skipStep2", skipStep2);

        state.setAdditionalProcessVariables(additionalProcessVariables);
        return state;
    }

    /**
     * If {@link WorkflowProcessEndState#isComplete()} returns {@code false} process does not end.
     * It returns successfully otherwise.
     * @param processDefinitionId the process definition ID, as defined in BPMN and saved in Activiti engine
     * @param variables combined process and task variables, defined in BPMN and programmatically during execution
     */
    @Override
    public WorkflowProcessEndState processEnd(String processDefinitionId, Map<String, Object> variables) {

        String approvalState = (String) variables.get(WorkflowVariables.VAR_APPROVAL_STATE.getValue());

        WorkflowProcessEndState state = new WorkflowProcessEndState();
        /*
         * Support process with definition Id 'demoApprovalProcess'.
         * Configuration element <conf:process id="..."
         */
        if (processDefinitionId.equals("demoApprovalProcess")) {

            // override default approval state if we have parallel tasks
            if (variables.containsKey(ROLE2_AS) && variables.containsKey(ROLE3_AS)) {
                String approvalState2 = (String) variables.get(ROLE2_AS);
                String approvalState3 = (String) variables.get(ROLE3_AS);
                if (approvalState2.equals("COMMIT") && approvalState3.equals("COMMIT")) {
                    approvalState = "COMMIT";
                } else if (approvalState2.equals("CANCEL") && approvalState3.equals("CANCEL")) {
                    approvalState = "CANCEL";
                } else {
                    approvalState = "RETURN";
                }
            }

            if (approvalState.equals("COMMIT")) {
                state.setComplete(true);
            } else {
                state.setComplete(false);
            }
        }

        if (processDefinitionId.equals("deleteApprovalProcess")) {
            if (approvalState.equals("ALLOW")) {
                state.setComplete(true);
            }
        }

        LOGGER.info(String.format("End process %s with action %s", processDefinitionId, approvalState));

        return state;
    }
}
