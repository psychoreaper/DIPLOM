# Unidata Resources Kit

## Book generation info

Для редактирования gitbook используйте _GitBook Editor_ \(инструмент устарел, и разработчик его более не поддерживает. _GitBook Editor _можно найти в интернете\).

Для генерации PDF

* Установите gitbook-cli \(уже содержится в Resources Kit\)

`npm install gitbook-cli -g`

* Установите calibre [https://calibre-ebook.com](https://calibre-ebook.com) \(дополнительных действий с calibre не требуется, она необходима для запуска gitbook\)

* Выполните скрипт:

build\_book.bat \(Windows\)  
build\_book.sh \(Linux\)

В случае появления ошибки «Error during ebook generation: "ebook-convert"» необходимо выполнить скрипт от имени Администратора

