package com.unidata.mdm.backend;

import com.unidata.mdm.backend.common.context.UpsertRequestContext;
import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitException;
import com.unidata.mdm.backend.common.integration.exits.ExitResult;
import com.unidata.mdm.backend.common.integration.exits.ExitState;
import com.unidata.mdm.backend.common.integration.exits.UpsertListener;
import com.unidata.mdm.backend.common.types.EtalonRecord;
import com.unidata.mdm.backend.common.types.OriginRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This user exit can be used for enrich etalon deactivation operation.
 * For example, you can add additional checks or logging.
 * This user exit contains 2 phases :
 *  1. before etalon deactivation where the operation started and can be interrupted,
 *  2. after etalon deactivation where the operation finished.
 */
public class SampleRestoreListener implements UpsertListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SampleRestoreListener.class);

    @Override
    public boolean beforeOriginUpdate(OriginRecord var1, ExecutionContext var2) {
        // Not implemented
        return true;
    }

    @Override
    public boolean beforeOriginInsert(OriginRecord var1, ExecutionContext var2) {
        // Not implemented
        return true;
    }

    @Override
    public void afterOriginUpdate(OriginRecord var1, ExecutionContext var2) {
        // Not implemented
    }

    @Override
    public void afterOriginInsert(OriginRecord var1, ExecutionContext var2) {
        // Not implemented
    }

    @Override
    public void afterUpdateEtalonComposition(EtalonRecord var1, ExecutionContext var2) {
        // Not implemented
    }

    @Override
    public void afterInsertEtalonComposition(EtalonRecord var1, ExecutionContext var2) {
        // Not implemented
    }

    @Override
    public ExitResult beforeRecordRestoreWithResult(ExecutionContext ctx) {
        LOGGER.info("Run before restore executor for record");
        if (ctx instanceof UpsertRequestContext) {
            UpsertRequestContext uCtx = (UpsertRequestContext) ctx;
            LOGGER.info("Restore record with id: " + uCtx.keys().getEtalonKey().getId());
        } else {
            throw new ExitException(ExitState.ES_GENERAL_FAILURE,
                    String.format("Restore request context has incorrect type "));
        }
        return new ExitResult(ExitResult.Status.SUCCESS);
    }
}
