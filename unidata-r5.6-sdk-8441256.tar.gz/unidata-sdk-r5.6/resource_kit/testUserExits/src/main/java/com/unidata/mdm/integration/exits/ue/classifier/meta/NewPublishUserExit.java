package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.context.classifier.context.NewModePublishVersionContext;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierMetaActionUserExitListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * publish version as new UE example
 *
 * @author maria.chistyakova
 * @since 24.11.2020
 */
public class NewPublishUserExit implements ClassifierMetaActionUserExitListener<NewModePublishVersionContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NewPublishUserExit.class);

    @Override
    public Boolean before(NewModePublishVersionContext context) {
        LOGGER.error("Before NewPublishUserExit: " + context.getClassifier());
        if (context.getDraft().getVersion().getDisplayName().startsWith("a")) {
            throw new RuntimeException("classifier version started from 'a' cannot be published as NEW version");
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean after(NewModePublishVersionContext context) {
        LOGGER.error("after NewPublishUserExit: " + context.getClassifier());
        return Boolean.TRUE;
    }
}
