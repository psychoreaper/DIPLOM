package com.unidata.mdm.integration.exits;

import java.util.Collections;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.unidata.mdm.backend.common.context.SearchRequestContext;
import com.unidata.mdm.backend.common.context.UpsertRequestContext;
import com.unidata.mdm.backend.common.dto.SearchResultDTO;
import com.unidata.mdm.backend.common.dto.UpsertRecordDTO;
import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitConstants;
import com.unidata.mdm.backend.common.integration.exits.ExitException;
import com.unidata.mdm.backend.common.integration.exits.UpsertListener;
import com.unidata.mdm.backend.common.record.SerializableDataRecord;
import com.unidata.mdm.backend.common.search.SearchRequestType;
import com.unidata.mdm.backend.common.service.DataRecordsService;
import com.unidata.mdm.backend.common.service.SearchService;
import com.unidata.mdm.backend.common.service.ServiceUtils;
import com.unidata.mdm.backend.common.types.EtalonRecord;
import com.unidata.mdm.backend.common.types.OriginRecord;
import com.unidata.mdm.backend.common.types.SimpleAttribute;

public class TestUpsertListener implements UpsertListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(TestUpsertListener.class);

    private static final String AFTER_INSERT_UE = "afterOriginInsert";

    private static final String BEFORE_INSERT_UE = "beforeOriginInsert";

    private static final String AFTER_UPDATE_UE = "afterOriginUpdate";

    private static final String BEFORE_UPDATE_UE = "beforeOriginUpdate";

    private static final String AFTER_UPDATE_COMP_UE = "afterUpdateEtalonComposition";

    private static final String AFTER_INSERT_COMP_UE = "afterInsertEtalonComposition";

    private static final String UPDATE = "update";

    private static final String INSERT = "insert";

    private static final String SOURCE_SYSTEM = "unidata";

    private static final String ETALON_ID = "$etalon_id";

    @Override
    public boolean beforeOriginUpdate(OriginRecord origin, ExecutionContext ctx) throws ExitException {
        Optional<SimpleAttribute<?>> originAttribute = origin.getSimpleAttributes().stream().findAny();
        if (originAttribute.isPresent()) {
            String name = originAttribute.get().getName();
            String value = originAttribute.get().castValue();
            if (value == null || !value.toLowerCase().contains(UPDATE)) {
                LOGGER.info(String.format("UserExit %s: attribute '%s' doesn't contain keyword '%s' - REJECT UPDATE",
                        BEFORE_UPDATE_UE, name, UPDATE));
                return false;
            } else {
                LOGGER.info(String.format("UserExit %s: attribute '%s' contains keyword '%s' - CONFIRM UPDATE",
                        BEFORE_UPDATE_UE, name, UPDATE));
                originAttribute.get().castValue(value + "_" + BEFORE_UPDATE_UE);
                LOGGER.info(String.format("UserExit %s: origin record with id=%s will be updated by user '%s'",
                        BEFORE_UPDATE_UE, origin.getInfoSection().getOriginKey().getId(),
                        ctx.getAuthenticationToken().getUserName()));
                return true;
            }
        } else {
            LOGGER.warn(
                    String.format("UserExit %s: there is no any STRING attribute found in entity", BEFORE_UPDATE_UE));
            return false;
        }
    }

    @Override
    public boolean beforeOriginInsert(OriginRecord origin, ExecutionContext ctx) throws ExitException {
        Optional<SimpleAttribute<?>> originAttribute = origin.getSimpleAttributes().stream().findAny();
        if (originAttribute.isPresent()) {
            String name = originAttribute.get().getName();
            String value = originAttribute.get().castValue();
            if (value == null || !value.toLowerCase().contains(INSERT)) {
                LOGGER.info(String.format("UserExit %s: attribute '%s' doesn't contain keyword '%s' - REJECT INSERT",
                        BEFORE_INSERT_UE, name, INSERT));
                return false;
            } else {
                LOGGER.info(String.format("UserExit %s: attribute '%s' contains keyword '%s' - CONFIRM INSERT",
                        BEFORE_INSERT_UE, name, INSERT));
                originAttribute.get().castValue(value + "_" + BEFORE_INSERT_UE);
                LOGGER.info(String.format("UserExit %s: origin record will be inserted by user '%s'", BEFORE_INSERT_UE,
                        ctx.getAuthenticationToken().getUserName()));
                return true;
            }
        } else {
            LOGGER.warn(
                    String.format("UserExit %s: there is no any STRING attribute found in entity", BEFORE_INSERT_UE));
            return false;
        }
    }

    @Override
    public void afterOriginUpdate(OriginRecord origin, ExecutionContext ctx) {
        ctx.putToUserContext(ExitConstants.OUT_UPSERT_CURRENT_RECORD_IS_MODIFIED.name(), Boolean.TRUE);
        Optional<SimpleAttribute<?>> originAttribute = origin.getSimpleAttributes().stream().findAny();
        String name = originAttribute.get().getName();
        String value = originAttribute.get().castValue();
        originAttribute.get().castValue(value + "_" + AFTER_UPDATE_UE);
        LOGGER.info(String.format("UserExit %s: origin record with id=%s (%s='%s') was updated by user '%s'",
                AFTER_UPDATE_UE, origin.getInfoSection().getOriginKey().getId(), name, value,
                ctx.getAuthenticationToken().getUserName()));
    }

    @Override
    public void afterOriginInsert(OriginRecord origin, ExecutionContext ctx) {
        ctx.putToUserContext(ExitConstants.OUT_UPSERT_CURRENT_RECORD_IS_MODIFIED.name(), Boolean.TRUE);
        Optional<SimpleAttribute<?>> originAttribute = origin.getSimpleAttributes().stream().findAny();
        String name = originAttribute.get().getName();
        String value = originAttribute.get().castValue();
        originAttribute.get().castValue(value + "_" + AFTER_INSERT_UE);
        LOGGER.info(String.format("UserExit %s: origin record with id=%s (%s='%s') was inserted by user '%s'",
                AFTER_INSERT_UE, origin.getInfoSection().getOriginKey().getId(), name, value,
                ctx.getAuthenticationToken().getUserName()));
    }

    @Override
    public void afterUpdateEtalonComposition(EtalonRecord etalon, ExecutionContext ctx) {
        Optional<SimpleAttribute<?>> etalonAttribute = etalon.getSimpleAttributes().stream().findAny();
        String name = etalonAttribute.get().getName();
        String value = etalonAttribute.get().castValue();
        String etalonId = etalon.getInfoSection().getEtalonKey().getId();
        LOGGER.info(String.format("UserExit %s: etalon record with id=%s (%s='%s') was updated by user '%s'",
                AFTER_UPDATE_COMP_UE, etalonId, name, value, ctx.getAuthenticationToken().getUserName()));
        SearchRequestContext searchCtx = SearchRequestContext.builder().entity(etalon.getInfoSection().getEntityName())
                .values(Collections.singletonList(etalonId)).search(SearchRequestType.TERM)
                .searchFields(Collections.singletonList(ETALON_ID)).returnFields(Collections.singletonList(name))
                .totalCount(true).countOnly(true).build();
        SearchService searchService = ServiceUtils.getSearchService();
        SearchResultDTO result = searchService.search(searchCtx);
        LOGGER.info(String.format("UserExit %s: SearchService: found %d etalon record by id=%s", AFTER_UPDATE_COMP_UE,
                result.getTotalCount(), etalonId));
    }

    @Override
    public void afterInsertEtalonComposition(EtalonRecord etalon, ExecutionContext ctx) {
        Optional<SimpleAttribute<?>> etalonAttribute = etalon.getSimpleAttributes().stream().findAny();
        String name = etalonAttribute.get().getName();
        String value = etalonAttribute.get().castValue();
        LOGGER.info(String.format("UserExit %s: etalon record with id=%s (%s='%s') was inserted by user '%s'",
                AFTER_INSERT_COMP_UE, etalon.getInfoSection().getEtalonKey().getId(), name, value,
                ctx.getAuthenticationToken().getUserName()));
        if (!value.contains(AFTER_INSERT_COMP_UE)) {
            SerializableDataRecord record = new SerializableDataRecord();
            record.putAttribute(name, AFTER_INSERT_COMP_UE);
            DataRecordsService dataRecordsService = ServiceUtils.getDataRecordsService();
            UpsertRequestContext requestContextBuilder = UpsertRequestContext.builder()
                    .entityName(etalon.getInfoSection().getEntityName()).sourceSystem(SOURCE_SYSTEM)
                    .externalId(UUID.randomUUID().toString()).record(record).build();
            UpsertRecordDTO result = dataRecordsService.upsertRecord(requestContextBuilder);
            LOGGER.info(String.format("UserExit %s: DataRecordsService: etalon record with id=%s was inserted",
                    AFTER_INSERT_COMP_UE, result.getKeys().getEtalonKey().getId()));
        }
    }

}
