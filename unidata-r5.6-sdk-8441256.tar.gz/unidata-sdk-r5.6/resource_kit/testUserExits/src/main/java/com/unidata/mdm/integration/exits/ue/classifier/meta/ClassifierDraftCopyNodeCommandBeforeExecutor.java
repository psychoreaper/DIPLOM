package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.dto.classifier.meta.ClassifierDraft;
import com.unidata.mdm.backend.common.dto.classifier.meta.draft.ClassifierCopyNodeCommand;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierCommandListener;
import com.unidata.mdm.backend.common.service.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * copy node in classifier draft UE example
 *
 * @author maria.chistyakova
 * @since 23.11.2020
 */
public class ClassifierDraftCopyNodeCommandBeforeExecutor implements ClassifierCommandListener<ClassifierCopyNodeCommand> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassifierDraftCopyNodeCommandBeforeExecutor.class);

    @Override
    public Boolean before(ClassifierCopyNodeCommand command, ClassifierDraft draft) {
        LOGGER.error("before ClassifierCopyNodeCommand");
        if (ServiceUtils.getClassifierDraftSearchService().fetchDraftBranchWithAttributes(draft.getClassifierName(), draft.getId(), command.getNewParentId()).get().getChildrenCount() > 3) {
            throw new RuntimeException("COPY NODE ERROR: parent node already has  3 children");
        }
        return true;
    }

}
