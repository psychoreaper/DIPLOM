package com.unidata.mdm.integration.exits;

import com.unidata.mdm.backend.common.integration.auth.User;
import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitException;
import com.unidata.mdm.backend.common.integration.exits.ExitState;
import com.unidata.mdm.backend.common.integration.exits.MergeListener;
import com.unidata.mdm.backend.common.types.EtalonRecord;
import com.unidata.mdm.backend.common.types.SimpleAttribute;
import com.unidata.mdm.backend.common.types.impl.BooleanSimpleAttributeImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
/*
 * This user exit can be used for enrich merge record operation.
 * For example, you can add additional checks or logging.
 * This user exit contains 2 phases :
 *  1. before merge where the operation started and can be interrupted,
 *  2. after merge where the operation finished.
 */
public class SampleMergeListener implements MergeListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SampleMergeListener.class);

    private static final String MERGE_FORBIDDEN_ATTRIBUTE  = "mergeForbidden";

    private static final String MERGE_ROLE = "mergeAdmin";

    @Override
    public boolean beforeMerge(EtalonRecord master, List<EtalonRecord> duplicates, ExecutionContext ctx) {
        // We can use the 'master' parameter for extract information about the master record being processed.
        // We can use the 'duplicates' parameter for extract information about the duplicate records being processed.
        // We can use the 'ctx' parameter for extract information about the operation context.

        //We get information about user, who run operation.
        User operationExecutor = ctx.getAuthenticationToken().getUserDetails();
        if(isCanMerge(operationExecutor)){
            // We can log error message or maybe throw exception.
            LOGGER.error("Merge operation available only for user with role %s ",
                    MERGE_ROLE);
            // ExitException is it special exception for user exits.
            throw new ExitException(ExitState.ES_GENERAL_FAILURE,
                    String.format("Merge operation available only for user with role %s ",
                            MERGE_ROLE));
        }

        //We can filter duplicates by additional restrictions.
        duplicates.removeIf(this::isMergeForbidden);

        boolean exitResult = true;
        if(duplicates.isEmpty()){
            // Also we can break operation without throw exception.
            exitResult = false;
        } else {
            exitResult = true;
        }
        return exitResult;
    }

    @Override
    public void afterMerge(EtalonRecord etalon, List<EtalonRecord> duplicates, ExecutionContext ctx) {
        // We also have information about the master record duplicates and the operation context in
        // 'after merge' phase.
        //We get information about user, who run operation.
        User operationExecutor = ctx.getAuthenticationToken().getUserDetails();
        // And nofity about success merge.
        sendEmailStub(operationExecutor.getEmail(), "Merge operation finished with status success");
    }


    private boolean isCanMerge(User operationExecutor) {
        return operationExecutor.getRoles() == null
                || operationExecutor.getRoles()
                .stream()
                .anyMatch(role -> MERGE_ROLE.equals(role.getName()));
    }

    private boolean isMergeForbidden(EtalonRecord record){
        SimpleAttribute mergeForbiddenAttr = record.getSimpleAttribute(MERGE_FORBIDDEN_ATTRIBUTE);
        return (mergeForbiddenAttr instanceof BooleanSimpleAttributeImpl
                && ((BooleanSimpleAttributeImpl)mergeForbiddenAttr).getValue());
    }


    private void sendEmailStub(String emailAddress, String message){

    }
}
