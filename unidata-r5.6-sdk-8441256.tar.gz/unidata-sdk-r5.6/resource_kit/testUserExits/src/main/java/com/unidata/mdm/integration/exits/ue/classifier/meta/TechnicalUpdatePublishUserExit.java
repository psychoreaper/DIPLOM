package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.context.classifier.context.TechUpdateModePublishVersionContext;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierMetaActionUserExitListener;
import com.unidata.mdm.backend.common.service.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * publish version in technical update UE example
 *
 * @author maria.chistyakova
 * @since 24.11.2020
 */
public class TechnicalUpdatePublishUserExit implements ClassifierMetaActionUserExitListener<TechUpdateModePublishVersionContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TechnicalUpdatePublishUserExit.class);


    @Override
    public Boolean before(TechUpdateModePublishVersionContext context) {
        LOGGER.error("Before TechnicalUpdatePublishUserExit: " + context.getClassifier());
        if (context.getDraft().getVersion().getDisplayName().startsWith("b") || ServiceUtils.getClassifierDraftSearchService().changeSetNodesSize(context.getDraft()) > 3) {
            throw new RuntimeException("before: classifier version  cannot be updated: it' name started from 'b' or too many changes (>3)");
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean after(TechUpdateModePublishVersionContext context) {
        LOGGER.error("after TechnicalUpdatePublishUserExit: " + context.getClassifier());
        return Boolean.TRUE;
    }
}
