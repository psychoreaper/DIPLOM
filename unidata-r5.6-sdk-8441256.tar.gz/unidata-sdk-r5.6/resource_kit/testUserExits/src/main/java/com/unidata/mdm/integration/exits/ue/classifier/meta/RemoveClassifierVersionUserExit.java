package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.context.classifier.context.RemoveClassifierVersionContext;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierMetaActionUserExitListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * remove classifier version  UE example
 *
 * @author maria.chistyakova
 * @since 18.01.2020
 */
public class RemoveClassifierVersionUserExit implements ClassifierMetaActionUserExitListener<RemoveClassifierVersionContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoveClassifierVersionUserExit.class);

    @Override
    public Boolean before(RemoveClassifierVersionContext context) {
        LOGGER.error("Before RemoveClassifierVersionUserExit: " + context.getClassifier());
        return Boolean.TRUE;
    }

    @Override
    public Boolean after(RemoveClassifierVersionContext context) {
        LOGGER.error("after RemoveClassifierVersionUserExit: " + context.getClassifier());
        return Boolean.TRUE;
    }
}
