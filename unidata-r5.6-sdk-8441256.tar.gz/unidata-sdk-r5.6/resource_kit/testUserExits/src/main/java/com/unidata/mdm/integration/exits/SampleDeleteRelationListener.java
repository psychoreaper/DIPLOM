package com.unidata.mdm.integration.exits;

import com.unidata.mdm.backend.common.context.DeleteRequestContext;
import com.unidata.mdm.backend.common.integration.auth.User;
import com.unidata.mdm.backend.common.integration.exits.ExitException;
import com.unidata.mdm.backend.common.integration.exits.ExitState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.unidata.mdm.backend.common.integration.exits.DeleteRelationListener;
import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitResult;
import com.unidata.mdm.backend.common.integration.exits.ExitResult.Status;
import com.unidata.mdm.backend.common.types.EtalonRelation;
/*
 * This user exit can be used for enrich relation deactivation operation.
 * For example, you can add additional checks or logging.
 * This user exit contains 2 phases :
 *  1. before relation deactivation where the operation started and can be interrupted,
 *  2. after relation deactivation where the operation finished.
 */
public class SampleDeleteRelationListener implements DeleteRelationListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SampleDeleteRelationListener.class);

    private static final String DEACTIVATE_RELATION_ROLE = "relationsAdmin";

    @Override
    public ExitResult beforeRelationDeactivation(EtalonRelation etalon, ExecutionContext ctx) {
        // We can use the 'etalon' parameter for extract information about the record being processed.
        // We get information about relation creator.
        String recordAuthor = etalon.getInfoSection().getCreatedBy();
        // Also we can use the 'ctx' parameter for extract information about operation context
        //We get information about user, who run operation.
        User operationExecutor = ctx.getAuthenticationToken().getUserDetails();
        ExitResult exitResult = null;

        if(isCanDeleteRelation(operationExecutor)){
            // We can log error message or maybe throw exception.
            LOGGER.error("Relation deactivation failed for record with identifier : %s",
                    etalon.getInfoSection().getRelationEtalonKey());
            // ExitException is it special exception for user exits.
            throw new ExitException(ExitState.ES_GENERAL_FAILURE,
                    String.format("Relation deactivation operation available only for user with role %s ",
                            DEACTIVATE_RELATION_ROLE));
        }

        if(!recordAuthor.equals(operationExecutor.getLogin())){
            // We can create exit result with different status.
            if(operationExecutor.isAdmin()){
                // Non interrupted status with warning message.
                exitResult = new ExitResult(Status.WARNING);
            } else {
                // Interrupted status with error message.
                exitResult = new ExitResult(Status.ERROR);
            }
            // Add new message for result
            exitResult.addWarning("The operation was not triggered by the author of the record");
        } else {
            // Success is it default exit status
            exitResult = new ExitResult();
        }
        return exitResult;
    }

    @Override
    public ExitResult afterRelationDeactivation(EtalonRelation etalon, ExecutionContext ctx) {
        // We also have information about the record and the operation context in
        // 'after etalon deactivation' phase.
        boolean isPhysical = ((DeleteRequestContext) ctx).isWipe();
        if (isPhysical) {
            LOGGER.info("Finish physical delete for record with identifier : %s. Operation identifier: %s ",
                    etalon.getInfoSection().getRelationEtalonKey(),
                    ((DeleteRequestContext) ctx).getOperationId());
        }
        return new ExitResult();
    }


    private boolean isCanDeleteRelation(User operationExecutor) {
        return operationExecutor.getRoles() == null
                || operationExecutor.getRoles()
                .stream()
                .anyMatch(role -> DEACTIVATE_RELATION_ROLE.equals(role.getName()));
    }

}
