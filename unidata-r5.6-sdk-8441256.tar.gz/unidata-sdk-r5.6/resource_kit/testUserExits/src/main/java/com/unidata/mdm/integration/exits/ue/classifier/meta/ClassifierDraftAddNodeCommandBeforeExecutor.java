package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.dto.classifier.meta.ClassifierDraft;
import com.unidata.mdm.backend.common.dto.classifier.meta.draft.ClassifierAddNodeCommand;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierCommandListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * add node in classifier draft UE example
 *
 * @author maria.chistyakova
 * @since 23.11.2020
 */
public class ClassifierDraftAddNodeCommandBeforeExecutor implements ClassifierCommandListener<ClassifierAddNodeCommand> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassifierDraftAddNodeCommandBeforeExecutor.class);

    @Override
    public Boolean before(ClassifierAddNodeCommand command, ClassifierDraft draft) {
        LOGGER.error("before ClassifierAddNodeCommand");

        if (command.getClassifierDraftNode().getDisplayName().length() < 3) {
            throw new RuntimeException("CREATE NODE ERROR: node display name length must be more than 3");
        }
        return true;
    }


}
