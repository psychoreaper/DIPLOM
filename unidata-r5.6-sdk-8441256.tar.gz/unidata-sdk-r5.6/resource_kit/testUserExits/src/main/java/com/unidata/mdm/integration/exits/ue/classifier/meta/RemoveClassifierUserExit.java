package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.context.classifier.context.RemoveClassifierContext;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierMetaActionUserExitListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * remove classifier UE example
 *
 * @author maria.chistyakova
 * @since 18.01.2020
 */
public class RemoveClassifierUserExit implements ClassifierMetaActionUserExitListener<RemoveClassifierContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoveClassifierUserExit.class);

    @Override
    public Boolean before(RemoveClassifierContext context) {
        LOGGER.error("Before RemoveClassifierUserExit: " + context.getClassifier());
        return Boolean.TRUE;
    }

    @Override
    public Boolean after(RemoveClassifierContext context) {
        LOGGER.error("after RemoveClassifierUserExit: " + context.getClassifier());
        return Boolean.TRUE;
    }
}
