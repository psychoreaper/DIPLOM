package com.unidata.mdm.integration.exits;

import com.unidata.mdm.backend.common.audit.AuditLevel;
import com.unidata.mdm.backend.common.context.DeleteRequestContext;
import com.unidata.mdm.backend.common.integration.exits.DeleteListener;
import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitException;
import com.unidata.mdm.backend.common.integration.exits.ExitState;
import com.unidata.mdm.backend.common.types.EtalonRecord;
import com.unidata.mdm.backend.common.types.SimpleAttribute;
import com.unidata.mdm.backend.common.types.impl.BooleanSimpleAttributeImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This user exit can be used for enrich etalon deactivation operation.
 * For example, you can add additional checks or logging.
 * This user exit contains 2 phases :
 *  1. before etalon deactivation where the operation started and can be interrupted,
 *  2. after etalon deactivation where the operation finished.
 */
public class SampleDeleteListener implements DeleteListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SampleDeleteListener.class);
    // this is the attribute that we will use for checking the removal capability.
    private static final String ATTRIBUTE_FOR_CHECK = "canRemovableFlag";

    @Override
    public boolean beforeEtalonDeactivation(EtalonRecord etalon, ExecutionContext ctx) {
        // We can use the 'etalon' parameter for extract information about the record being processed.
        // We get information about attribute by name
        SimpleAttribute canRemovableFlag = etalon.getSimpleAttribute(ATTRIBUTE_FOR_CHECK);
        // Also we can use the 'ctx' parameter for extract information about operation context
        //We get information about the audit level
        int auditLevel = ((DeleteRequestContext) ctx).getAuditLevel();

        if (!(canRemovableFlag instanceof BooleanSimpleAttributeImpl)) {
            // We can log error message or maybe throw exception.
            LOGGER.error("Etalon deactivation not available for record with identifier : %s",
                    etalon.getInfoSection().getEtalonKey().getId());
            // ExitException is it special exception for user exits.
            throw new ExitException(ExitState.ES_VALIDATION_ERROR,
                    String.format("Can't find required attribute %s for etalon deactivation", ATTRIBUTE_FOR_CHECK));
        }

        if (((BooleanSimpleAttributeImpl) canRemovableFlag).getValue() == Boolean.FALSE) {
            // Also we can break operation without throw exception.
            LOGGER.error("Etalon deactivation not available for record with identifier : %s",
                    etalon.getInfoSection().getEtalonKey().getId());
            return false;
        }

        // We can use some information about operation context.
        // For example we write additional message about start operation, if is need.
        if (AuditLevel.AUDIT_SUCCESS <= auditLevel) {
            LOGGER.info("Start etalon deactivation for record with identifier : %s",
                    etalon.getInfoSection().getEtalonKey().getId());
        }
        return true;
    }

    @Override
    public void afterEtalonDeactivation(EtalonRecord etalon, ExecutionContext ctx) {
        // We also have information about the record and the operation context in
        // 'after etalon deactivation' phase.
        boolean isPhysical = ((DeleteRequestContext) ctx).isWipe();
        if (isPhysical) {
            LOGGER.info("Finish physical delete for record with identifier : %s. Operation identifier: %s ",
                    etalon.getInfoSection().getEtalonKey().getId(),
                    ((DeleteRequestContext) ctx).getOperationId());
        }
    }
}
