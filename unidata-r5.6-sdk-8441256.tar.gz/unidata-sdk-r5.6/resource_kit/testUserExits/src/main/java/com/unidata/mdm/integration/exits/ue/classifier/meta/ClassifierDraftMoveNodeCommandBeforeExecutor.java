package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.dto.classifier.meta.ClassifierDraft;
import com.unidata.mdm.backend.common.dto.classifier.meta.draft.ClassifierMoveNodeCommand;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierCommandListener;
import com.unidata.mdm.backend.common.service.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * move node in classifier draft UE example
 *
 * @author maria.chistyakova
 * @since 23.11.2020
 */
public class ClassifierDraftMoveNodeCommandBeforeExecutor implements ClassifierCommandListener<ClassifierMoveNodeCommand> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassifierDraftMoveNodeCommandBeforeExecutor.class);


    @Override
    public Boolean before(ClassifierMoveNodeCommand command, ClassifierDraft draft) {
        LOGGER.error("before ClassifierMoveNodeCommand");
        if (ServiceUtils.getClassifierDraftSearchService().fetchDraftBranchWithAttributes(draft.getClassifierName(), draft.getId(), command.getNewParentId()).get().getChildrenCount() > 3) {
            throw new RuntimeException("MOVE NODE ERROR: parent node already has  3 children");
        }

        return true;
    }
}
