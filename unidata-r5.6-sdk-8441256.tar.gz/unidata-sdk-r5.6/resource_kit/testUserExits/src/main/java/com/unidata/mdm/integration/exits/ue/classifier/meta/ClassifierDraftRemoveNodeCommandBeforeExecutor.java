package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.dto.classifier.meta.ClassifierDraft;
import com.unidata.mdm.backend.common.dto.classifier.meta.draft.ClassifierRemoveNodeCommand;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierCommandListener;
import com.unidata.mdm.backend.common.service.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * remove node in classifier draft UE example
 *
 * @author maria.chistyakova
 * @since 23.11.2020
 */
public class ClassifierDraftRemoveNodeCommandBeforeExecutor implements ClassifierCommandListener<ClassifierRemoveNodeCommand> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassifierDraftRemoveNodeCommandBeforeExecutor.class);


    @Override
    public Boolean before(ClassifierRemoveNodeCommand command, ClassifierDraft draft) {
        LOGGER.error("before ClassifierRemoveNodeCommand");
        if (ServiceUtils.getClassifierDraftSearchService().fetchDraftBranchWithAttributes(draft.getClassifierName(), draft.getId(), command.getNodeId()).get().getChildrenCount() != 0) {
            throw new RuntimeException("REMOVE NODE ERROR: node has children");
        }
        return true;
    }
}
