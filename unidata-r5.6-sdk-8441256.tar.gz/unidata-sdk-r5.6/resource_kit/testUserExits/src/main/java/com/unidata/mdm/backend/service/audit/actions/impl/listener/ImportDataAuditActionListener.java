package com.unidata.mdm.backend.service.audit.actions.impl.listener;

import java.util.List;
import java.util.function.BiConsumer;

import com.unidata.mdm.backend.common.integration.exits.AfterAuditListener;

public class ImportDataAuditActionListener implements AfterAuditListener {

    @Override
    public boolean beforeSave(List<String> customAuditUsableFields, BiConsumer<String, String> putUserDetails, Object... input) {
        customAuditUsableFields.forEach(f -> putUserDetails.accept(f, "test sample"));
        return false;
    }
}
