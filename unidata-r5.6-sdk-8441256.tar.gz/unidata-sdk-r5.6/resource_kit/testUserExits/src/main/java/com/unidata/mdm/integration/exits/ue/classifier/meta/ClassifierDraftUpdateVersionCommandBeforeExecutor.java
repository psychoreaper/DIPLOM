package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.dto.classifier.meta.ClassifierDraft;
import com.unidata.mdm.backend.common.dto.classifier.meta.draft.ClassifierUpdateVersionCommand;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierCommandListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * update version in classifier draft UE example
 *
 * @author maria.chistyakova
 * @since 23.11.2020
 */
public class ClassifierDraftUpdateVersionCommandBeforeExecutor implements ClassifierCommandListener<ClassifierUpdateVersionCommand> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassifierDraftUpdateVersionCommandBeforeExecutor.class);


    @Override
    public Boolean before(ClassifierUpdateVersionCommand command, ClassifierDraft draft) {
        LOGGER.error("before ClassifierUpdateVersionCommand");
        if (command.getTo().getDisplayName().length() < 3) {
            throw new RuntimeException("UPDATE VERSION ERROR: version display name length must be more than 3");
        }
        return true;
    }
}
