package com.unidata.mdm.integration.exits.ue.classifier.meta;

import com.unidata.mdm.backend.common.dto.classifier.meta.ClassifierDraft;
import com.unidata.mdm.backend.common.dto.classifier.meta.draft.ClassifierUpdateNodeCommand;
import com.unidata.mdm.backend.common.integration.exits.classifiers.ClassifierCommandListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * update node in classifier draft UE example
 *
 * @author maria.chistyakova
 * @since 23.11.2020
 */
public class ClassifierDraftUpdateNodeCommandBeforeExecutor implements ClassifierCommandListener<ClassifierUpdateNodeCommand> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassifierDraftUpdateNodeCommandBeforeExecutor.class);


    @Override
    public Boolean before(ClassifierUpdateNodeCommand command, ClassifierDraft draft) {
        LOGGER.error("before ClassifierUpdateNodeCommand");
        if (command.getClassifierDraftNode().getDisplayName().length() < 3) {
            throw new RuntimeException("UPDATE NODE ERROR: node display name length must be more than 3");
        }
        return true;
    }
}
