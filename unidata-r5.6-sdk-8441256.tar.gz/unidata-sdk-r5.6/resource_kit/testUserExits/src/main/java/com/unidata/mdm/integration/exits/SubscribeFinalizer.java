package com.unidata.mdm.integration.exits;

import java.util.Collection;
import java.util.List;

import com.unidata.mdm.backend.common.context.CommonTransactionalContext;
import com.unidata.mdm.backend.common.context.DeleteClassifierDataRequestContext;
import com.unidata.mdm.backend.common.context.DeleteRelationRequestContext;
import com.unidata.mdm.backend.common.context.DeleteRequestContext;
import com.unidata.mdm.backend.common.context.GetRequestContext;
import com.unidata.mdm.backend.common.context.MergeRequestContext;
import com.unidata.mdm.backend.common.context.SplitContext;
import com.unidata.mdm.backend.common.context.UpsertClassifierDataRequestContext;
import com.unidata.mdm.backend.common.context.UpsertRelationRequestContext;
import com.unidata.mdm.backend.common.context.UpsertRequestContext;
import com.unidata.mdm.backend.common.dto.GetRecordDTO;
import com.unidata.mdm.backend.common.exception.DataProcessingException;
import com.unidata.mdm.backend.common.exception.ExceptionId;
import com.unidata.mdm.backend.common.integration.exits.AfterSplitListener;
import com.unidata.mdm.backend.common.integration.exits.BeforeSplitListener;
import com.unidata.mdm.backend.common.integration.exits.DeleteClassifierListener;
import com.unidata.mdm.backend.common.integration.exits.DeleteListener;
import com.unidata.mdm.backend.common.integration.exits.DeleteRelationListener;
import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitResult;
import com.unidata.mdm.backend.common.integration.exits.MergeListener;
import com.unidata.mdm.backend.common.integration.exits.UpsertClassifierListener;
import com.unidata.mdm.backend.common.integration.exits.UpsertListener;
import com.unidata.mdm.backend.common.integration.exits.UpsertRelationListener;
import com.unidata.mdm.backend.common.keys.RecordKeys;
import com.unidata.mdm.backend.common.service.ServiceUtils;
import com.unidata.mdm.backend.common.types.EtalonClassifier;
import com.unidata.mdm.backend.common.types.EtalonRecord;
import com.unidata.mdm.backend.common.types.EtalonRelation;
import com.unidata.mdm.backend.common.types.OriginClassifier;
import com.unidata.mdm.backend.common.types.OriginRecord;
import com.unidata.mdm.backend.common.types.OriginRelation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SubscribeFinalizer implements UpsertListener, UpsertRelationListener, DeleteRelationListener,
        UpsertClassifierListener, DeleteClassifierListener, DeleteListener, MergeListener, BeforeSplitListener, AfterSplitListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(SubscribeFinalizer.class);

    public SubscribeFinalizer() {

    }

    @Override
    public ExitResult beforeOriginClassifierUpdate(OriginClassifier origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN CLASSIFIER UPDATE");
        return new ExitResult();
    }

    @Override
    public ExitResult beforeOriginClassifierInsert(OriginClassifier origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN CLASSIFIER INSERT");
        return new ExitResult();
    }

    @Override
    public ExitResult afterOriginClassifierUpdate(OriginClassifier origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN CLASSIFIER UPDATE");
        return new ExitResult();
    }

    @Override
    public ExitResult afterOriginClassifierInsert(OriginClassifier origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN CLASSIFIER INSERT");
        return new ExitResult();
    }

    @Override
    public  ExitResult beforeClassifierDeactivation(EtalonClassifier etalonClassifier, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "BEFORE CLASSIFIER DEACTIVATION");
        return new ExitResult();
    }

    @Override
    public  ExitResult afterClassifierDeactivation(EtalonClassifier etalonClassifier, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "AFTER CLASSIFIER DEACTIVATION");
        return new ExitResult();
    }

    @Override
    public boolean beforeOriginUpdate(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN UPDATE");
        return true;
    }

    @Override
    public boolean beforeOriginInsert(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN INSERT");
        return true;
    }
    @Override
    public void afterOriginUpdate(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN UPDATE");
    }
    @Override
    public void afterOriginInsert(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN INSERT");
    }
    @Override
    public void afterUpdateEtalonComposition(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER UPDATE ETALON");
    }
    @Override
    public void afterInsertEtalonComposition(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ETALON COMPOSITION");
    }

    @Override
    public ExitResult beforeOriginUpdateWithResult(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN UPDATE");
        return new ExitResult();
    }

    @Override
    public ExitResult beforeOriginInsertWithResult(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN INSERT");
        return new ExitResult();
    }
    @Override
    public ExitResult afterOriginUpdateWithResult(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN UPDATE");
        return new ExitResult();
    }
    @Override
    public ExitResult afterOriginInsertWithResult(OriginRecord origin, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN INSERT");
        return new ExitResult();
    }
    @Override
    public ExitResult afterUpdateEtalonCompositionWithResult(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER EtALON COMPOSITION");
        return new ExitResult();
    }
    @Override
    public ExitResult afterInsertEtalonCompositionWithResult(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ETALON COMPOSITION");
        return new ExitResult();
    }

    @Override
    public boolean beforeEtalonDeactivation(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ETALON DEACTIVATION");
        return true;
    }

    @Override
    public ExitResult beforeEtalonDeactivationWithResult(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE ETALON DEACTIVATION");
        return new ExitResult();
    }

    @Override
    public void afterEtalonDeactivation(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ETALON DEACTIVATION");
    }

    @Override
    public ExitResult afterEtalonDeactivationWithResult(EtalonRecord etalon, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER ETALON DEACTIVATION");
        return new ExitResult();
    }

    public void subscribe(CommonTransactionalContext ctx, String name) {
        CommonTransactionalContext dCtx = ctx;

        dCtx.addFinalizeExecutor(t -> {
            RecordKeys keys = null;
            if (t instanceof UpsertRequestContext) {
                keys = ((UpsertRequestContext) t).keys();
            }
            if (t instanceof DeleteRequestContext) {
                keys = ((DeleteRequestContext) t).keys();
            }
            if (t instanceof UpsertRelationRequestContext) {
                keys = ((UpsertRelationRequestContext) t).relationKeys().getFrom();
            }
            if (t instanceof DeleteRelationRequestContext) {
                keys = ((DeleteRelationRequestContext) t).relationKeys().getFrom();
            }
            if (t instanceof UpsertClassifierDataRequestContext) {
                keys = ((UpsertClassifierDataRequestContext) t).classifierKeys().getRecord();
            }
            if (t instanceof DeleteClassifierDataRequestContext) {
                keys = ((DeleteClassifierDataRequestContext) t).classifierKeys().getRecord();
            }
            if (t instanceof MergeRequestContext) {
                keys = ((MergeRequestContext) t).keys();
                if (keys == null) {
                    keys = ((MergeRequestContext) t).duplicateKeys().get(((MergeRequestContext) t).duplicateKeys().size() - 1);
                }
            }
            if (t instanceof SplitContext) {
                keys = ((SplitContext) t).keys();
            }

            GetRequestContext getRequestContext = GetRequestContext.builder()
                    .entityName(keys.getEntityName())
                    .etalonKey(keys.getEtalonKey().getId())
                    .fetchRelations(true)
                    .fetchClassifiers(true)
                    .build();
            try {
                GetRecordDTO recordDTO = ServiceUtils.getDataRecordsService().getRecord(getRequestContext);

                StringBuilder sb = new StringBuilder();
                if (recordDTO == null) {
                    sb.append("RECORD WITH NAME " + keys.getEntityName() + " AND ID " + keys.getEtalonKey().getId() + " NOT FOUND");
                    LOGGER.info(sb.toString());
                    return true;
                }
                sb.append("-------------------------------------------------------");
                sb.append(System.lineSeparator());
                sb.append("USER exit: " + name);
                sb.append(System.lineSeparator());
                sb.append(String.format("Record %s  has attr value : %s", keys.getEtalonKey().getId(),
                        recordDTO.getEtalon() == null || recordDTO.getEtalon().getSimpleAttribute("name") == null
                                ? null :recordDTO.getEtalon().getSimpleAttribute("name").getValue()));
                sb.append(System.lineSeparator());
                recordDTO.getRelations().values().stream().flatMap(Collection::stream).forEach(getRelationDTO -> {
                    sb.append(String.format("Relation with name %s and id %s has attr value: %s ",
                            getRelationDTO.getRelName(),
                            getRelationDTO.getRelationKeys().getEtalonId(),
                            getRelationDTO.getEtalon() == null || getRelationDTO.getEtalon().getSimpleAttribute("name") == null
                                    ? null : getRelationDTO.getEtalon().getSimpleAttribute("name").getValue()));
                    sb.append(System.lineSeparator());
                });
                recordDTO.getClassifiers().values().stream().flatMap(Collection::stream).forEach(getClassifierDTO -> {
                    sb.append(String.format("Classifier with name %s and id %s has attr value: %s ",
                            getClassifierDTO.getClassifierKeys().getName(),
                            getClassifierDTO.getClassifierKeys().getEtalonId(),
                            getClassifierDTO.getEtalon() == null || getClassifierDTO.getEtalon().getSimpleAttribute("name") == null
                                    ? null : getClassifierDTO.getEtalon().getSimpleAttribute("name").getValue()));
                    sb.append(System.lineSeparator());
                });
                sb.append(System.lineSeparator());
                sb.append("-------------------------------------------------------");

                LOGGER.info(sb.toString());
                return true;
            } catch (DataProcessingException ex) {
                if (ex.getId() == ExceptionId.EX_DATA_GET_NOT_FOUND_BY_SUPPLIED_KEYS) {
                    LOGGER.info("RECORD WITH NAME " + keys.getEntityName() + " AND ID " + keys.getEtalonKey().getId() + " NOT FOUND");
                }
            }
            return true;

        });
    }

    @Override
    public ExitResult beforeOriginRelationUpdate(OriginRelation origin, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN RELATION UPDATE");
        return new ExitResult();
    }

    @Override
    public ExitResult beforeOriginRelationInsert(OriginRelation origin, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "BEFORE ORIGIN RELATION INSERT");
        return new ExitResult();
    }

    @Override
    public ExitResult afterOriginRelationUpdate(OriginRelation origin, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN RELATION UPDATE");
        return new ExitResult();
    }

    @Override
    public ExitResult afterOriginRelationInsert(OriginRelation origin, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "AFTER ORIGIN RELATION INSERT");
        return new ExitResult();
    }

    @Override
    public ExitResult beforeRelationDeactivation(EtalonRelation etalonRelation, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "BEFORE RELATION DEACTIOVATION");
        return new ExitResult();
    }

    @Override
    public ExitResult afterRelationDeactivation(EtalonRelation etalonRelation, ExecutionContext ctx){
        subscribe((CommonTransactionalContext) ctx, "AFTER RELATION DEACTIVATION");
        return new ExitResult();
    }
    @Override
    public boolean beforeMerge(EtalonRecord etalon, List<EtalonRecord> duplicates, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE MERGE");
        return true;
    }

    @Override
    public ExitResult beforeMergeWithResult(EtalonRecord etalon, List<EtalonRecord> duplicates, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "BEFORE MERGE");
        return new ExitResult();
    }

    @Override
    public void afterMerge(EtalonRecord etalon, List<EtalonRecord> duplicates, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER MERGE");
    }

    @Override
    public ExitResult afterMergeWithResult(EtalonRecord etalon, List<EtalonRecord> duplicates, ExecutionContext ctx) {
        subscribe((CommonTransactionalContext) ctx, "AFTER MERGE");
        return new ExitResult();
    }

    @Override
    public ExitResult beforeSplit(SplitContext splitContext) {
        subscribe((CommonTransactionalContext) splitContext, "BEFORE SPLIT");
        return new ExitResult();
    }

    @Override
    public ExitResult afterSplit(SplitContext splitContext) {
        subscribe((CommonTransactionalContext) splitContext, "AFTER SPLIT");
        return new ExitResult();
    }
}