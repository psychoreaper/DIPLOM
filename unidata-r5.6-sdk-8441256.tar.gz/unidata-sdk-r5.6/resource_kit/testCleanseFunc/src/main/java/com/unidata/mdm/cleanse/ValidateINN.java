package com.unidata.mdm.cleanse;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.unidata.mdm.backend.common.cleanse.CleanseFunction;
import com.unidata.mdm.backend.common.types.SimpleAttribute;
import com.unidata.mdm.backend.common.types.impl.BooleanSimpleAttributeImpl;
import com.unidata.mdm.meta.CleanseFunctionExtendedDef;
import com.unidata.mdm.meta.Port;
import com.unidata.mdm.meta.SimpleDataType;

/**
 * Функция производит валидацию ИНН.
 *
 */
public class ValidateINN implements CleanseFunction {

    /**
     * ИНН может быть только 10 или 12 символьной строкой содержащей только
     * цифровые символы.
     */
    private static final Pattern INN_PATTERN = Pattern.compile("\\d{10}|\\d{12}");

    /**
     * Контрольная сумма ИНН проверяется по определнному паттерну, данный массив
     * содержит этот паттерн.
     */
    private static final int[] IN_CHECK_ARR = new int[] { 3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8 };

    /*
     * (non-Javadoc)
     * 
     * @see com.unidata.mdm.cleanse.CleanseFunction#getDefinition()
     */
    @Override
    public CleanseFunctionExtendedDef getDefinition() {

        CleanseFunctionExtendedDef definition = new CleanseFunctionExtendedDef();

        // -------------------------------------------------------------
        // Устанавливаем описание функции
        definition.setDescription("Validate INN number");
        // Устанавливаем имя функции
        definition.setFunctionName("CustomValidateINN");
        definition.setJavaClass(this.getClass().getCanonicalName());

        // -------------------------------------------------------------
        // Добавляем входящий порт(в нашем примере только один, но входящих
        // портов может быть неограниченное количество)
        definition.getInputPorts()
                .add(new Port()
                        // тип входящего порта, в нашем случае строка
                        .withDataType(SimpleDataType.STRING)
                        // описание входящего порта
                        .withDescription("ИНН(индивидуальный налоговый номер)")
                        // имя входящего порта
                        .withName("INN")
                        // обязательно ли порт должен быть заполнен для
                        // успешного выполнения функции
                        .withRequired(true));

        // -------------------------------------------------------------
        // Добавляем исходящий порт(в нашем примере только один, но исходящих
        // портов может быть неограниченное количество)
        definition.getOutputPorts()
                .add(new Port()
                        // тип исходящего порта, в нашем случае boolean
                        .withDataType(SimpleDataType.BOOLEAN)
                        // описание исходящего порта
                        .withDescription("ИНН валиден?")
                        // имя исходящего порта
                        .withName("isValid")
                        // обязательно ли порт должен быть заполнен для
                        // успешного выполнения функции
                        .withRequired(true));
        return definition;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.unidata.mdm.cleanse.CleanseFunction#execute(java.util.Map)
     */
    @Override
    public Map<String, Object> execute(Map<String, Object> input) {
        // Получаем значение ИНН
        String inn = ((SimpleAttribute<?>) input.get("INN")).castValue();
        // Выполняем проверку в соответствии с алгоритмом
        boolean isValid = isValidINN(inn);
        // Создаем и заполняем результат который будет возвращен при выполнении
        // данной функции
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("isValid", new BooleanSimpleAttributeImpl("isValid", isValid));
        // Возвращаем результат
        return result;
    }

    /**
     * Метод производит проверку ИНН на валидность. 1) Проверяет формат ИНН в
     * соответствии с паттерном INN_PATTERN 2) Если проверка по паттерну
     * пройдена, то проверяет контрольную сумму.
     * 
     * @param innString ИНН в виде строки.
     * @return true если проверка пройдена, в противном случае false
     */
    private static boolean isValidINN(String innString) {
        innString = innString.trim();
        if (!INN_PATTERN.matcher(innString).matches()) {
            return false;
        }
        int length = innString.length();
        if (length == 12) {
            return checkINNSum(innString, 2, 1) && checkINNSum(innString, 1, 0);
        } else {
            return checkINNSum(innString, 1, 2);
        }
    }

    /**
     * Метод производит вычисление и проверку контрольной суммы ИНН.
     * 
     * @param inn - ИНН
     * @param offset - сдвиг
     * @param arrOffset - сдвиг
     * @return true если проверка пройдена, в противном случае false
     */
    private static boolean checkINNSum(String inn, int offset, int arrOffset) {
        int sum = 0;
        int length = inn.length();
        for (int i = 0; i < length - offset; i++) {
            sum += (inn.charAt(i) - '0') * IN_CHECK_ARR[i + arrOffset];
        }
        return (sum % 11) % 10 == inn.charAt(length - offset) - '0';
    }
}