'use strict';

const path = require('path');

module.exports = {
  dev: {
      host: 'localhost',
      port: 3030,

      assetsPublicPath: '/',

      // https://webpack.js.org/configuration/devtool/#development
      devtool: false
  },

  build: {
      assetsRoot: path.resolve(__dirname, '../../dist'),
      assetsPublicPath: '/',

      // https://webpack.js.org/configuration/devtool/#production
      devtool: false
  }
};
