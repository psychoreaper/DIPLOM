import * as T from './MyReactComponent.js'

export default {
    type: 'type',
    moduleId: 'my-first-import',
    active: true,
    system: true,
    resolver: function () {
    },
    fn: function () {
    },
    T: T
}
