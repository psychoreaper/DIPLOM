declare global {
    interface Window {
        UnidataReact: any;
    }
}

interface IProps {
    label: string;
}

interface IState {
}

let React = window.UnidataReact.React;

class Component extends React.Component <IProps, IState> {

    componentDidMount() {
        console.log('CUX mount');
    }

    render() {
        return (<div>
            <div>I AM CUX</div>
            <div>My props: {this.props.label}</div>
        </div>)
    }
}

export default {
    type: 'type',
    moduleId: 'my-first-component',
    active: true,
    system: true,
    resolver: function () {
        return true;
    },
    component: Component
}
