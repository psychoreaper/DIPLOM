export default {
    type: 'type',
    moduleId: 'my-first-callback',
    active: true,
    system: true,
    resolver: function () {
        debugger
    },
    fn: function () {
        debugger
    }
}
