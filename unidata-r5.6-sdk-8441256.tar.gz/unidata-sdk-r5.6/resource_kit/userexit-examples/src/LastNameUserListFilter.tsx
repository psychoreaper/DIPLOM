declare global {
    interface Window {
        UnidataReact: any;
    }
}

interface IProps {
    onFilterChange: (fn: null | ((user: any) => boolean)) => void;
}

interface IState {
    currentValue: any;
}

let React = window.UnidataReact.React;
let components = window.UnidataReact.components;

class FilterComponent extends React.Component <IProps, IState> {
    state: IState = {
        currentValue: ''
    };

    render () {
        const self = this;
        const {FieldInput} = components;

        return (
            <>
                Фамилия:
                <FieldInput
                    inputSpan={24}
                    defaultValue={this.state.currentValue}
                    onChange={function (prevValue: any, value: any) {
                        if (value.length) {
                            self.props.onFilterChange(function (user: any) {
                                return user.lastName.getValue().indexOf(value) !== -1;
                            })
                        } else {
                            self.props.onFilterChange(null);
                        }

                        self.setState({
                            currentValue: value
                        })
                    }}
                />
            </>
        );
    }
}

export default {
    type: 'USER_LIST_FILTER',
    moduleId: 'lastnameUserListFilter',
    active: true,
    system: false,
    resolver: function () {
        return true;
    },
    component: FilterComponent
};
