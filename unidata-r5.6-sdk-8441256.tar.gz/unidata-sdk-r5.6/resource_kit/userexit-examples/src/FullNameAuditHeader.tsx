// Необходимый класс для вывода в react компонент
let React = window.UnidataReact.React;

export default {
    // системные параметры необходимые для координации плагина
    type: 'AUDIT_HEADER',
    moduleId: 'full-name-header',
    active: true,
    system: false,
    // функция которая изменяет заголовок таблицы и список отображения
    fn: (tableHeader: any, headerList: any) => {
        // добавляем столбец
        tableHeader.push({
            id: 'full_name',
            accessor: 'full_name',
            Header: () => 'FULL NAME',
            filterable: true,
            sortable: false,
            Cell: (row :any) => {
                return (<div>{row.original.full_name}</div>);
            },
        });
        // добавляем в список отображения
        headerList.columnNameMapper['full_name'] = () => 'FULL NAME';
    }
}
