﻿/**
 * Пример расширения PasswordPolicy
 *
 * Правило что пароль должен содержать цифры
 *
 * @author Vladimir Stebunov
 * @date 2020-03-11
 */

// Необходимый класс для вывода в react компонент
let React = window.UnidataReact.React;

export default {
    // системные параметры необходимые для координации плагина
    type: 'PASSWORD_POLICY',
    moduleId: 'digit-password-policy',
    active: true,
    system: false,
    /**
     * функция проверки что пароль валиден
     *
     * @newPassword пароль для проверки
     * @return сообщение об ошибке или ничего если всё правильно заполнено
     */
    fn: (newPassword: string): string | undefined => {
       const isContainsDiggit = new RegExp(/.*[0-9].*/, 'g');

       if (!isContainsDiggit.test(newPassword)) {
           return 'Пароль должен содержать хотя бы одну цифру';
       }

       return;
    }
}
