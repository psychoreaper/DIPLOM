declare global {
    interface Window {
        UnidataReact: any;
    }
}

interface IRole {
    key: string;
    text: string;
}

interface INamedArray {
    [key: string]: string;
}

interface IProps {
    selected: INamedArray;
    complete: IRole[];
    user: any;
}

interface IState {
    addition: INamedArray;
}

const CUSTOM_COLUMN_NAME = 'role_time';

let React = window.UnidataReact.React;
let components = window.UnidataReact.components;

class RoleComponent extends React.Component <IProps, IState> {
    state: IState = {
        addition: {}
    }

    setStateByProp () {
        const { selected, user } = this.props;
        const property = user.properties.items.filter((i: any) => i.name.getValue() === CUSTOM_COLUMN_NAME)[0];

        if (!property) {
            console.error('Properties doesn\'t exist ', CUSTOM_COLUMN_NAME);

            return;
        }

        const unparsedAddition = property.value.getValue();

        let addition: INamedArray = {};

        if (unparsedAddition && unparsedAddition.length > 0) {
            try {
                addition = JSON.parse(unparsedAddition);

                Object.keys(addition).forEach((key) => {
                    if (selected.indexOf(key) < 0) {
                        delete addition[key];
                    }
                });
            } catch (e) {
                console.error('Wrong JSON!', property.value.getValue());
                console.error(e);
            }
        }

        this.setState({
            addition: addition
        });
    }

    showWindow = () => {
        const { ModalStates } = components;

        this.setStateByProp();
        window.dispatchEvent(new CustomEvent(ModalStates.Open, {detail: {id: 'role-customizer'}}));
    }

    onOk = () => {
        const { ModalStates } = components;
        const { user } = this.props;
        const property = user.properties.items.filter((i: any) => i.name.getValue() === CUSTOM_COLUMN_NAME)[0];

        if (!property) {
            console.error('Properties doesn\'t exist ', CUSTOM_COLUMN_NAME);

            return;
        }

        property.value.setValue(JSON.stringify(this.state.addition));

        window.dispatchEvent(new CustomEvent(ModalStates.Close, {detail: {id: 'role-customizer'}}));
    }

    onChange = (name: string, value: string) => {
        this.setState({
            addition: { ...this.state.addition, [name]: value }
        });
    }

    render () {
        const {ModalWindow, FieldInput} = components;
        const {selected, complete} = this.props;
        const {addition} = this.state;
        const onChange = this.onChange;
        const labels: INamedArray = {};

        complete.map((role: IRole) => labels[role.key] = role.text);

        return (<div style={{textAlign: 'right', position: 'absolute', top: '9px', right: '15px'}}>
            <span onClick={this.showWindow} className='ud-icon icon-cog ud-icon-large ud-linear-icon ud-icon-has-hover'></span>

            <ModalWindow
                id={'role-customizer'}
                title={'Правка атрибутов роли'}
                onOk={this.onOk}>
                        {selected.map(function (item: any, index: any) {
                            return (
                                <FieldInput
                                    label={labels[item]}
                                    onChange={onChange}
                                    key={item}
                                    name={item}
                                    defaultValue={addition && addition[item]}
                                />
                            );
                        })}
            </ModalWindow>
        </div>);
    }
}

export default {
    type: 'ROLE_CUSTOMIZER',
    moduleId: 'RoleCustomization',
    active: true,
    system: false,
    resolver: function () {
        return true;
    },
    component: RoleComponent
};
