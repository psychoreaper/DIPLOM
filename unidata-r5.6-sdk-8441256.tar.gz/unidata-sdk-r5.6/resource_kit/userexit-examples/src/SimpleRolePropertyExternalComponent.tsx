﻿declare global {
    interface Window {
        UnidataReact: any;
    }
}

interface IProps {
    name: string,
        label: string,
        defaultValue: string,
        disabled: boolean,
        onChange: Function,
        error: string
}

interface IState {
}

let React = window.UnidataReact.React;
let components = window.UnidataReact.components;

class SimpleRolePropertyExternalComponent extends React.Component <IProps, IState> {
    render () {
	console.log('Simple props', this.props);
        return (
            <select
		value={this.props.value || ''}
		onChange={this.props.onChange}
		name={this.props.name}		
		className={this.props.className || 'ant-input'}
		style={this.props.style}>
                <option value="Лыцк">Лыцк</option>
                <option value="Баклужино">Баклужино</option>
            </select>
        );
    }
}

export default {
    type: 'PROPERTY_EXTERNAL_COMPONENT',
    moduleId: 'ВыборРайона',
    active: true,
    system: false,
    resolver: function () {
        return true;
    },
    component: SimpleRolePropertyExternalComponent
};
