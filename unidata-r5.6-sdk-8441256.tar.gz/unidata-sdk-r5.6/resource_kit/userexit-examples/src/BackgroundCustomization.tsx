// Необходимый класс для вывода в react компонент
let React = window.UnidataReact.React;

export default {
    // системные параметры необходимые для координации плагина
    type: 'SET_PASSWORD_BACKGROUND',
    moduleId: 'simple-background',
    active: true,
    system: false,
    // функция которая отдаёт стиль фона
    fn: () => {
        return {
            background: 'url(http://www.catcorporation.local/cat-loginbackground-user.jpg)',
            backgroundSize: 'cover'
        }
    }
}

