﻿/**
 * Пример расширения колонки аудита AUDIT_HEADER
 *
 * Добавляем столбец "День". Получает строку из таблицы аудита, берёт 
 * дату и выводит день недели раскрашивая в цвет по чётности
 *
 * @author Vladimir Stebunov
 * @date 2019-09-16
 */

// Дополнительные массивы для работы плагина
const dayofweek = [
    'Вск',
    'Пн',
    'Вт',
    'Ср',
    'Чт',
    'Пт',
    'Сб'
]

const colorofday = [
    'red',
    'blue'
]

// Необходимый класс для вывода в react компонент
let React = window.UnidataReact.React;

export default {
    // системные параметры необходимые для координации плагина
    type: 'AUDIT_HEADER',
    moduleId: 'days-audit-header',
    active: true,
    system: false,
    // функция которая изменяет заголовок таблицы и список отображения
    fn: (tableHeader: any, headerList: any) => {
        // добавляем столбец
        tableHeader.push({
            id: 'days',
            accessor: 'days',
            Header: () => 'День',
            Cell: (row :any) => {
                // Получаем дату события конкретной строки и выводим день недели
                // раскрашивая в цвет в зависимости от чётности
                var d = new Date(row.original.date).getDay();
                return (<div style={{color: colorofday[Math.ceil(d % 2)]}}>{dayofweek[d]}</div>);
            },	    	   
	    Filter: (filterProps: any) => {
		return ( 
			<input
			type="text"
	                onChange={filterProps.onChange}
                	style={{width: '100%', height: 32}}
		            />
		);
	    }            
        });
        // добавляем в список отображения
        headerList.columnNameMapper['days'] = () => 'День';
    }
}
