declare global {
    interface Window {
        UnidataReact: any;
    }
}

interface IProps {
    name: string,
        label: string,
        defaultValue: string,
        disabled: boolean,
        onChange: Function,
        error: string
}

interface IState {
}

const CUSTOM_COLUMN_NAME = 'role_time';

let React = window.UnidataReact.React;
let components = window.UnidataReact.components;

class SimpleRolePropertyExternalComponent extends React.Component <IProps, IState> {
    render () {
        const {label, defaultValue} = this.props;
        return (<div style={{border: '1px solid blue'}}>
            testMe {label} : {defaultValue}
        </div>);
    }
}

export default {
    type: 'PROPERTY_EXTERNAL_COMPONENT',
    moduleId: 'Blue',
    active: true,
    system: false,
    resolver: function () {
        return true;
    },
    component: SimpleRolePropertyExternalComponent
};
