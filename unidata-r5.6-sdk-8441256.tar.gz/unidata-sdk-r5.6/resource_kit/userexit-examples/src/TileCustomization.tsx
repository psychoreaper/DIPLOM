// Необходимый класс для вывода в react компонент
let React = window.UnidataReact.React;

export default {
    // системные параметры необходимые для координации плагина
    type: 'TRANSFORM_RESULT_VALUES',
    moduleId: 'color-result-values',
    active: true,
    system: false,
    // функция которая изменяет заголовок таблицы и список отображения
    fn: (metaAttribute: any, formattedValue: any) => {
        if (metaAttribute.mainDisplayable.value) {
            return formattedValue.map( (value: string) => {
                return value.replace(/(\d+)/g, '<span style="color:green; font-size: 16px; background: orange;">$1</span>');
            })
        }
    }
}

