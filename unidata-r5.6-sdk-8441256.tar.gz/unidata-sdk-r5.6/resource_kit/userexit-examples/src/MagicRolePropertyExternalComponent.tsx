﻿declare global {
    interface Window {
        UnidataReact: any;
    }
}

interface IProps {
    name: string,
    value: string,
    disabled: boolean,
    onChange: Function,
    error: string,
    className: string,
    style: string
}

interface IState {
}

let React = window.UnidataReact.React;
let components = window.UnidataReact.components;

class MagicRolePropertyExternalComponent extends React.Component <IProps, IState> {
    render () {
        return (
            <select 
                value={this.props.value || ''}
                onChange={this.props.onChange}
                name={this.props.name}
                className={this.props.className || 'ant-input'}
                style={this.props.style}>
                    <option value="Огонь">Огонь</option>
                    <option value="Вода">Вода</option>
                    <option value="Земля">Земля</option>
                    <option value="Темная материя">Темная материя</option>
                    <option value="">Отсутствует</option>
            </select>
        );
    }
}

export default {
    type: 'PROPERTY_EXTERNAL_COMPONENT',
    moduleId: 'ВыборСтихии',
    active: true,
    system: false,
    resolver: function () {
        return true;
    },
    component: MagicRolePropertyExternalComponent
};
