# Примеры реализаций UI UE для UnidataReact

## Сборка UI UE

Для сборки последовательно выполнить команды

```
npm install
npm run build
```

Пересборка проекта:
```
npm run rebuild
```

Очистка проекта:

```
npm run clean
```

В результате исполнения в каталоге `unidata-resource-kit\userexit-examples\build` будут созданы js файлы, которые можно подключать к платформе.
