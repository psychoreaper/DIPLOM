System.register([], function (exports_1, context_1) {
    "use strict";
    var React;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            // Необходимый класс для вывода в react компонент
            React = window.UnidataReact.React;
            exports_1("default", {
                // системные параметры необходимые для координации плагина
                type: 'AUDIT_HEADER',
                moduleId: 'full-name-header',
                active: true,
                system: false,
                // функция которая изменяет заголовок таблицы и список отображения
                fn: function (tableHeader, headerList) {
                    // добавляем столбец
                    tableHeader.push({
                        id: 'full_name',
                        accessor: 'full_name',
                        Header: function () { return 'FULL NAME'; },
                        filterable: true,
                        sortable: false,
                        Cell: function (row) {
                            return (React.createElement("div", null, row.original.full_name));
                        },
                    });
                    // добавляем в список отображения
                    headerList.columnNameMapper['full_name'] = function () { return 'FULL NAME'; };
                }
            });
        }
    };
});
//# sourceMappingURL=FullNameAuditHeader.js.map