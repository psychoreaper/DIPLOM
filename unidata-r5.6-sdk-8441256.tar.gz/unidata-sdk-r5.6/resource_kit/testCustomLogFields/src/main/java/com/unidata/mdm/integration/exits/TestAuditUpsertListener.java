package com.unidata.mdm.integration.exits;

import com.unidata.mdm.backend.common.integration.exits.ExecutionContext;
import com.unidata.mdm.backend.common.integration.exits.ExitException;
import com.unidata.mdm.backend.common.integration.exits.ExitResult;
import com.unidata.mdm.backend.common.integration.exits.UpsertListener;
import com.unidata.mdm.backend.common.types.EtalonRecord;
import com.unidata.mdm.backend.common.types.OriginRecord;
import com.unidata.mdm.backend.service.audit.AuditEventsWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@Component
public class TestAuditUpsertListener implements UpsertListener {


    @Autowired
    private AuditEventsWriter auditEventsWriter;

    @Override
    public boolean beforeOriginUpdate(OriginRecord origin, ExecutionContext ctx) throws ExitException {
        return true;
    }

    @Override
    public boolean beforeOriginInsert(OriginRecord origin, ExecutionContext ctx) throws ExitException {
        return true;
    }

    @Override
    public void afterOriginUpdate(OriginRecord origin, ExecutionContext ctx) {
    }

    @Override
    public void afterOriginInsert(OriginRecord origin, ExecutionContext ctx) {
    }

    @Override
    public void afterUpdateEtalonComposition(EtalonRecord etalon, ExecutionContext ctx) {
    }

    @Override
    public void afterInsertEtalonComposition(EtalonRecord etalon, ExecutionContext ctx) {
    }

    @Override
    public ExitResult beforeOriginInsertWithResult(OriginRecord origin, ExecutionContext ctx) {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
        auditEventsWriter.writeSuccessEvent( new TestUpsertListenerAuditEvent(), "full_user_name_beforeOriginInsertWithResult_action");
        return new ExitResult();
    }

    @Override
    public ExitResult afterOriginInsertWithResult(OriginRecord origin, ExecutionContext ctx) {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
        auditEventsWriter.writeSuccessEvent( new TestUpsertListenerAuditEvent(), "full_user_name_afterOriginInsertWithResult_action");
        return new ExitResult();
    }
}
