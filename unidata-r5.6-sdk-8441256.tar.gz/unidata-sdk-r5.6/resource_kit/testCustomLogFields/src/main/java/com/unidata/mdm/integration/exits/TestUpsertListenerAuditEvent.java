package com.unidata.mdm.integration.exits;

import com.unidata.mdm.backend.service.audit.SubSystem;
import com.unidata.mdm.backend.service.audit.actions.AuditAction;
import com.unidata.mdm.backend.service.search.Event;


public class TestUpsertListenerAuditEvent implements AuditAction {


    @Override
    public void enrichEvent(Event event, Object... input) {
        String fullName = (String) input[0];
        event.putUserDefinedData("full_name", fullName);
    }

    @Override
    public SubSystem getSubsystem() {
        return SubSystem.USER_DEFINED;
    }

    /**
     * check correct input
     *
     * @param input
     * @return
     */
    @Override
    public boolean isValidInput(Object... input) {
        return input.length == 1 && input[0] instanceof String;
    }

    @Override
    public String name() {
        return "TestUpsertListenerAuditEvent";
    }
}
