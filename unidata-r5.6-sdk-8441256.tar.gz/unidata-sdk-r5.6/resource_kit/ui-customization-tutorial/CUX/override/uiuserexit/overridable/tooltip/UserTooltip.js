Ext.define('CUX.override.uiuserexit.overridable.tooltip.UserTooltip', {

    override: 'Unidata.uiuserexit.overridable.tooltip.UserTooltip',

    /**
     * Функция для построения tpl
     *
     * @param {Unidata.model.user.User} user
     * @return {Object}
     */
    buildTpl: function () {
        return [
            '<div>',
            '<div>{login}</div>',
            '<tpl for="properties">',
            '<div>{displayName}</div>',
            '<div>{value}</div>',
            '</tpl>',
            '</div>'
        ];
    },

    /**
     * Данные пользователя, которые мы собираемся передать tpl
     *
     * @param {Unidata.model.user.User} user
     * @return {Object}
     */
    collectUserData: function (user) {
        var userData = {
            login: user.get('login')
        };

        return userData;
    },

    /**
     * Данные userProperty пользователя, которые мы собираемся передать tpl
     *
     * @param {Unidata.model.user.UserProperty} user
     * @return {Object}
     */
    collectProperties: function (user) {

        var properties = user.get('properties') || [];

        //фильтруем пустые значения
        return properties.filter(function (prop) {
            return Boolean(prop.value);
        });
    }
});
