Ext.define('CUX.override.uiuserexit.overridable.cluster.Merge', {
    override: 'Unidata.uiuserexit.overridable.cluster.Merge',

    singleton: true,

    /**
     * Флаг деактивации панели 'Результат консолидации'
     */
    disablePreviewPanel: false,

    /**
     * Вызывается при отображении превью
     *
     * возвращает метод, который выполняет обращение к API,
     * парсит response и возвращает Promise
     *
     * @param previewConfig {Object} - конфиг предварительного просмотра операции слияния.
     * - etalonIds - массив id консолидируемых строк - ['823ff18d-2a97', '124dff6e-655d']
     * - winners - массив объектов строк (id и источники данных) - [{id: '82...', paths: ['inn']}, ...]
     * - entityName - имя реестра / справочника
     *
     * @return {function | undefined | false}
     */

    getManualMergePreview: function (previewConfig) { // jscs:ignore disallowUnusedParams
        return this.customPreviewExample(previewConfig);
    },

    /**
     * Вызывается при клике на кнопку 'Объединить'
     *
     * возвращает метод, который выполняет обращение к API,
     * парсит response и возвращает Promise
     *
     * @param mergeConfig {Object} - конфиг предварительного просмотра операции слияния.
     * - etalonIds - массив id консолидируемых строк - ['823ff18d-2a97', '124dff6e-655d']
     * - winners - массив объектов строк (id и источники данных) - [{id: '82...', paths: ['inn']}, ...]
     * - entityName - имя реестра / справочника
     *
     * @return {function | undefined | false}
     */

    doMerge: function (mergeConfig) { // jscs:ignore disallowUnusedParams
        return this.customMergeExample(mergeConfig);
    },

    /**
     *
     * customPreviewExample - кастомизация предварительного результата консолидации
     * customMergeExample - кастомизация окончательной консолидации
     *
     * Общая логика: если редактируется запись из реестра 'Person' - применить кастомные методы.
     *
     * В качестве кастомных запросов, используются запросы из текущего API UniData.
     *
     */
    customPreviewExample: function (previewConfig) {
        if (!previewConfig) {
            return false;
        }

        switch (previewConfig.entityName) {
            case 'Person':
                return previewPerson;
            default:
                return false;
        }

        function previewPerson (previewConfig) {
            var deferred = Ext.create('Ext.Deferred');

            Ext.Ajax.request({
                method: 'POST',
                url: Unidata.Api.createUrl('/data/merge/preview'),
                success: function (response) {
                    deferred.resolve(Unidata.util.api.Merge.parseManualMergePreviewResponse(response));
                },
                failure: function () {
                    deferred.reject();
                },
                jsonData: Ext.util.JSON.encode(previewConfig),
                scope: this
            });

            return deferred.promise;
        }
    },

    customMergeExample: function (mergeConfig) {
        if (!mergeConfig) {
            return false;
        }

        switch (mergeConfig.entityName) {
            case 'Person':
                return mergePerson;
            default:
                return false;
        }

        function mergePerson (mergeConfig) {
            var deferred = Ext.create('Ext.Deferred');

            Ext.Ajax.request({
                method: 'POST',
                url: Unidata.Api.createUrl('/data/merge/apply'),
                success: function (response) {
                    deferred.resolve(Unidata.util.api.Merge.parseDoManualMergeResponse(response));
                },
                failure: function () {
                    deferred.reject();
                },
                jsonData: Ext.util.JSON.encode(mergeConfig),
                scope: this
            });

            return deferred.promise;
        }
    }
});
