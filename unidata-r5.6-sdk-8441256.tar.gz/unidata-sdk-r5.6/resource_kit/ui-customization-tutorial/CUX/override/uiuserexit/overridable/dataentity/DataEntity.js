/**
 * Расширение для управления узлами классификатора на карточке записи
 *
 * @author Aleksandr Bavin
 * @date 2018-06-01
 */
Ext.define('CUX.override.uiuserexit.overridable.dataentity.DataEntity', {

    override: 'Unidata.uiuserexit.overridable.dataentity.DataEntity',

    // кэш отфильтрованных узлов классификатора по каждому dataEntity
    nodesByClassifierNamePromises: {},

    getClassifierNodeEditorWindowConfig: function (metaRecord, dataRecord, classifier) {
        return this.loadDataRecordClassifiersFilterData(metaRecord, dataRecord)
            .then(
                function (nodesByClassifierName) {
                    var classifierName = classifier.get('name'),
                        nodes = nodesByClassifierName[classifierName],
                        classifierTreeConfig = null;

                    if (nodes) {
                        // фильтруем
                        if (nodes.length) {
                            classifierTreeConfig = this.getClassifierTreeConfig(nodes);
                        } else {
                            classifierTreeConfig = {
                                searchTextFieldHidden: true,
                                root: {}
                            };
                        }
                    }

                    return {
                        classifierTreeConfig: classifierTreeConfig
                    };
                }.bind(this)
            );
    },

    onDataEntityDisplay: function (dataEntity) {
        var dataRecord = dataEntity.getDataRecord(),
            metaRecord = dataEntity.getMetaRecord(),
            transcodingData,
            masterClassifiers;

        // получаем метаданные перекодировки
        // transcodingData = this.getClassifierTranscodingData(metaRecord);

        this.loadDataRecordClassifiersFilterData(metaRecord, dataRecord)
            // .then(
            //     Ext.bind(this.filterClassifierNodes, this, [dataEntity, transcodingData], true)
            // )
            .done();
    },

    getDataRecordId: function (dataRecord) {
        var etalonId = dataRecord.get('etalonId');

        if (!Ext.isEmpty(etalonId)) {
            return etalonId;
        }

        // если запись новая, то ориентируемся по временному id
        return dataRecord.getId();
    },

    /**
     * Загружает все данные по фильтрации для slave от masterClassifiers
     *
     * @param metaRecord
     * @param dataRecord
     * @returns {Ext.promise.Promise}
     */
    loadDataRecordClassifiersFilterData: function (metaRecord, dataRecord) {
        var transcodingData = this.getClassifierTranscodingData(metaRecord), // получаем метаданные перекодировки
            masterClassifiers = this.getMasterClassifiers(transcodingData),
            classifiers,
            promisedData = [],
            dataRecordId = this.getDataRecordId(dataRecord),
            promise = this.nodesByClassifierNamePromises[dataRecordId];

        if (!dataRecord.classifiers) {
            return Ext.Deferred.resolved([]);
        }

        if (promise) {
            return promise;
        }

        classifiers = dataRecord.classifiers();

        Ext.Array.each(masterClassifiers, function (classifierName) {
            var slavesByTable;

            // получаем карту "теблица перекодировки - зависимые классификаторы"
            slavesByTable = this.getSlavesByTable(transcodingData, classifierName);

            if (Ext.Object.isEmpty(slavesByTable)) {
                return;
            }

            classifiers.each(function (classifier) {
                var selectedNodeId;

                if (classifier.get('classifierName') === classifierName) {
                    selectedNodeId = classifier.get('classifierNodeId');

                    if (!selectedNodeId) {
                        return;
                    }

                    this.loadClassifierFilterData(classifierName, selectedNodeId, promisedData, slavesByTable);
                }
            }, this);
        }, this);

        promise = this.runPromisedDataIteration(promisedData)
            .then(function (data) { // чистим данные от мусора
                return Ext.Array.clean(Ext.Array.flatten(data));
            })
            .then(function (data) { // список узлов для каждого slave классификатора
                var nodesByClassifierName = {};

                Ext.Array.each(data, function (dataItem) {
                    var classifierName = dataItem.classifierName;

                    if (!nodesByClassifierName[classifierName]) {
                        nodesByClassifierName[classifierName] = [];
                    }

                    if (dataItem.node) {
                        nodesByClassifierName[classifierName].push(dataItem.node);
                    }
                });

                return nodesByClassifierName;
            });

        return promise;
    },

    /**
     * Загрузка данных для фильтрации по классификатору
     *
     * @param masterClassifierName
     * @param selectedNodeId
     * @param promisedData
     * @param slavesByTable
     */
    loadClassifierFilterData: function (masterClassifierName, selectedNodeId, promisedData, slavesByTable) {
        // запускаем поиск по таблицам перекодировки
        Ext.Object.each(slavesByTable, function (table, slaveClassifiers) {
            var searchQuery = new Unidata.module.search.DataSearchQuery(),
                supplementaryRequestTerm = new Unidata.module.search.term.classifier.SupplementaryRequest(),
                supplementarySearchQuery = supplementaryRequestTerm.getSupplementarySearchQuery(),
                formField = supplementarySearchQuery.getNodeTerm(),
                deferredSearch = new Ext.Deferred();

            promisedData.push(deferredSearch.promise);

            searchQuery.getEntityTerm().setName(table);

            formField.setName(masterClassifierName + '.$nodes.$node_id');
            formField.setValue(selectedNodeId);
            searchQuery.addTerm(supplementaryRequestTerm);

            searchQuery
                .search()
                .then(
                    function (searchHits) {

                        // загружаем записи
                        Ext.Array.each(searchHits, function (hit) {
                            var deferredDataRecord = new Ext.Deferred(),
                                etalonId = hit.get('etalonId');

                            promisedData.push(deferredDataRecord.promise);

                            Unidata.util.api.DataRecord.getDataRecord({
                                etalonId: etalonId,
                                intervalActive: true
                            }).then(
                                function (dataRecord) {
                                    var classifiers = dataRecord.classifiers(),
                                        dataRecordSlaveClassifiers = [],
                                        wrongSearchHit = true;

                                    // проверяем наличие нужного master классификатора
                                    classifiers.each(function (classifier) {
                                        var hitClassifierName = classifier.get('classifierName'),
                                            hitClassifierNodeId = classifier.get('classifierNodeId');

                                        if (masterClassifierName === hitClassifierName &&
                                            selectedNodeId === hitClassifierNodeId) {
                                            wrongSearchHit = false;

                                            return false;
                                        }
                                    });

                                    if (wrongSearchHit) {
                                        deferredDataRecord.resolve();

                                        return;
                                    }

                                    classifiers.each(function (classifier) {
                                        var classifierName = classifier.get('classifierName'),
                                            classifierNodeId = classifier.get('classifierNodeId'),
                                            deferredClassifierNode;

                                        // если slave
                                        if (slaveClassifiers.indexOf(classifierName) !== -1) {
                                            dataRecordSlaveClassifiers.push(classifierName);

                                            deferredClassifierNode = new Ext.Deferred();

                                            promisedData.push(deferredClassifierNode.promise);

                                            // загружаем узлы
                                            Unidata.util.api.Classifier.getRootNodeForClassifierNode(classifierName, classifierNodeId, 'PATH')
                                                .then(
                                                    function (node) {
                                                        deferredClassifierNode.resolve({
                                                            classifierName: classifierName,
                                                            node: node
                                                        });
                                                    },
                                                    function (e) {
                                                        deferredClassifierNode.reject(e);
                                                    }
                                                )
                                                .done();
                                        }
                                    });

                                    // если запись без slave классификатора, то резолвим без ноды
                                    // что бы понимать, что фильтр должен исключить все узлы
                                    if (!dataRecordSlaveClassifiers.length) {
                                        Ext.Array.each(slaveClassifiers, function (slaveClassifier) {
                                            promisedData.push(Ext.Deferred.resolved({
                                                classifierName: slaveClassifier,
                                                node: null
                                            }));
                                        });
                                    }

                                    deferredDataRecord.resolve();
                                },
                                function (e) {
                                    deferredDataRecord.reject(e);
                                }
                            );
                        });

                        deferredSearch.resolve();
                    },
                    function (e) {
                        deferredSearch.reject(e);
                    }
                )
                .done();
        }, this);
    },

    /**
     * Фильтрация узлов классификатора
     *
     * @param nodesByClassifierName - список узлов для каждого slave классификатора
     * @param dataEntity
     * @param transcodingData
     * @deprecated В новой реализации не используется, оставлено на случай, если опять понадобится
     */
    filterClassifierNodes: function (nodesByClassifierName, dataEntity, transcodingData) {
        var metaRecord = dataEntity.getMetaRecord(),
            metaRecordClassifiers = metaRecord.get('classifiers') || [];

        Ext.Array.each(metaRecordClassifiers, function (classifierName) {
            // запускаем фильтрацию по каждой панельки с классификатором
            dataEntity.executeByClassifierName(
                this.classifierItemFilterExecuteCallback,
                classifierName,
                [classifierName, nodesByClassifierName],
                this
            );
        }, this);
    },

    classifierItemFilterExecuteCallback: function (classifierItem, classifierName, nodesByClassifierName) {
        var nodes = nodesByClassifierName[classifierName],
            classifierTreeConfig;

        if (!nodes) {
            // сбрасываем фильтрацию, если необходимо
            classifierItem.setClassifierTreeConfig(null);
        } else {
            // фильтруем
            if (nodes.length) {
                classifierTreeConfig = this.getClassifierTreeConfig(nodes);

                classifierItem.setClassifierTreeConfig(classifierTreeConfig);
            } else {
                classifierItem.setClassifierTreeConfig({
                    searchTextFieldHidden: true,
                    root: {}
                });
            }
        }
    },

    /**
     * Собирает общее дерево узлов классификатора
     */
    getClassifierTreeConfig: function (nodes) {
        var allowedNodeIds = [],
            rootNode,
            concatSameIdNodes,
            config;

        rootNode = nodes[0];

        // собираем разные деревья в одно
        concatSameIdNodes = function (nodes) {
            var result = [],
                childrenByNodeId = {};

            // группируем дочерние ноды по nodeId
            Ext.Array.each(nodes, function (node) {
                if (node.children && node.children.length) {
                    Ext.Array.each(node.children, function (node) {
                        var nodeId = node.id;

                        if (!childrenByNodeId[nodeId]) {
                            childrenByNodeId[nodeId] = [];
                        }

                        childrenByNodeId[nodeId].push(node);
                    });
                } else {
                    // узел без дочерних элементов - доступен для выбора
                    Ext.Array.include(allowedNodeIds, node.id);
                }
            });

            Ext.Object.each(childrenByNodeId, function (nodeId, nodes) {
                var firstNode = nodes[0],
                    children = concatSameIdNodes(nodes),
                    hasChildren = Boolean(children.length);

                // выбираем одну ноду для результата
                result.push(firstNode);
                firstNode.children = children;
                firstNode.childCount = children.length;
                firstNode.leaf = !hasChildren;
                firstNode.expanded = true;

                if (allowedNodeIds.indexOf(nodeId) === -1) {
                    firstNode.cls = 'un-grid-cell-disabled';
                }
            });

            return result;
        };

        rootNode.children = concatSameIdNodes(nodes);
        rootNode.childCount = rootNode.children.length;

        config = {
            root: rootNode,
            searchTextFieldHidden: true,
            listeners: {
                beforeselect: function (selectionModel, node) {
                    if (allowedNodeIds.indexOf(node.id) === -1) {
                        return false;
                    }
                }
            }
        };

        return config;
    },

    /**
     * Вызывается при выборе узла классификатора пользователем
     *
     * @param {Unidata.view.steward.dataentity.DataEntity} dataEntity - панель классификатора, для которой произошло изменение узла
     * @param {string} classifierName - имя классификатора, для которого измениля узел
     * @param {Unidata.model.classifier.ClassifierNode | null} selectedNode - новый узел классификатора
     * @param {Unidata.model.classifier.ClassifierNode | null} deselectedNode - старый узел классификатора
     * @param {Ext.Deferred} deferredNodeChange - отложенная перезагрузка карточки, необходимо зарезолвить для продолжения работы
     * @returns {boolean} - если вернули false, то перезагрузка карточки будет приостановлена до резолва deferredNodeChange
     */
    onClassifierNodeChange: function (dataEntity, classifierName, selectedNode, deselectedNode, deferredNodeChange) {
        var metaRecord = dataEntity.getMetaRecord(),
            dataRecord,
            transcodingData,
            classifiersToReset,
            masterClassifiers;

        // получаем метаданные перекодировки
        transcodingData = this.getClassifierTranscodingData(metaRecord);

        // список классификаторов, которые нужно сбросить
        classifiersToReset = this.getClassifiersToReset(transcodingData, classifierName);

        if (classifiersToReset.length) {
            dataRecord = dataEntity.getDataRecord();

            // сбрасываем slave классификаторы, с учетом возможных иерархий
            Ext.Array.each(classifiersToReset, function (classifierName) {
                var dataRecordClassifiers = dataRecord.classifiers(),
                    removeClassifiers = [];

                dataRecordClassifiers.each(function (classifier) {
                    if (classifier.get('classifierName') !== classifierName) {
                        return;
                    }

                    if (classifier.phantom) {
                        removeClassifiers.push(classifier);
                    } else {
                        classifier.set('classifierNodeId', null);
                        classifier.simpleAttributes().removeAll();
                    }
                });

                dataRecordClassifiers.remove(removeClassifiers);
            });

            // убираем отфильтрованные данные из кэша
            delete this.nodesByClassifierNamePromises[this.getDataRecordId(dataRecord)];

            // в данный момент нет необходимости фильтровать панельки при изменении узла,
            // т.к. фильтрация запускается при перерисовке карточки записи,
            // перерисовка происходит при каждом изменении узла

            // masterClassifiers = this.getMasterClassifiers(transcodingData, classifiersToReset);
            //
            // this.loadDataRecordClassifiersFilterData(dataRecord, masterClassifiers, transcodingData)
            //     .then(
            //         Ext.bind(this.filterClassifierNodes, this, [dataEntity, transcodingData], true)
            //     )
            //     .always(
            //         function () {
            //             deferredNodeChange.resolve();
            //         }
            //     )
            //     .done();
            //
            // return false;
        }
    },

    runPromisedDataIteration: function (promisedData) {
        var me = this;

        return Ext.Deferred.all(promisedData)
            .then(
                function (data) {
                    // запускаем новую итерацию, если появились новые промисы
                    if (promisedData.length !== data.length) {
                        return me.runPromisedDataIteration(promisedData);
                    }

                    return data;
                }
            );
    },

    /**
     * @typedef {Object} TranscodingDataItem
     * @property {string} table - имя реестра, таблицы перекодировки
     * @property {string} master - имя главного классификатора
     * @property {string} slave - имя зависимого классификатора
     */

    /**
     *
     * @param metaRecord
     * @returns {TranscodingDataItem[]}
     */
    getClassifierTranscodingData: function (metaRecord) {
        var customProperties = metaRecord.customProperties(),
            transcodingDataItems = [],
            masterClassifierProp;

        // находим нужные метаданные
        masterClassifierProp = customProperties.findRecord('name', 'CLASSIFIER_TRANSCODING', 0, false, true, true);

        if (masterClassifierProp && (transcodingDataItems = masterClassifierProp.get('value'))) {
            // декодируем JSON
            transcodingDataItems = JSON.parse(transcodingDataItems);
        }

        return transcodingDataItems;
    },

    /**
     * Возвращает список зависимых классификаторов
     *
     * @param transcodingData
     * @param [masterClassifiers] - фильтрация по master
     * @returns {Array}
     */
    getSlaveClassifiers: function (transcodingData, masterClassifiers) {
        var slaveClassifiers = [];

        Ext.Array.each(transcodingData, function (item) {
            var addToResult = true;

            if (masterClassifiers && masterClassifiers.length) {
                addToResult = masterClassifiers.indexOf(item.master) !== -1;
            }

            if (addToResult) {
                Ext.Array.include(slaveClassifiers, item.slave);
            }
        }, this);

        return slaveClassifiers;
    },

    /**
     * Возвращает список главных классификаторов
     *
     * @param transcodingData
     * @param [slaveClassifiers] - фильтрация по slave
     * @returns {Array}
     */
    getMasterClassifiers: function (transcodingData, slaveClassifiers) {
        var masterClassifiers = [];

        Ext.Array.each(transcodingData, function (item) {
            var addToResult = true;

            if (slaveClassifiers && slaveClassifiers.length) {
                addToResult = slaveClassifiers.indexOf(item.slave) !== -1;
            }

            if (addToResult) {
                Ext.Array.include(masterClassifiers, item.master);
            }
        }, this);

        return masterClassifiers;
    },

    /**
     * Возвращает список классификаторов, которые необходимо сбросить, учетом возможных иерархий
     *
     * @param {TranscodingDataItem[]} transcodingData
     * @param {string} masterClassifierName
     * @returns {string[]}
     */
    getClassifiersToReset: function (transcodingData, masterClassifierName) {
        var classifiersToReset = [];

        Ext.Array.each(transcodingData, function (item) {
            if (this.hasMaster(transcodingData, item, masterClassifierName)) {
                classifiersToReset.push(item.slave);
            }
        }, this);

        return Ext.Array.unique(classifiersToReset);
    },

    /**
     * Проверяет, есть ли родительский классификатор с заданным именем
     *
     * @param {TranscodingDataItem[]} transcodingData
     * @param {TranscodingDataItem} dataItem
     * @param {string} masterName
     */
    hasMaster: function (transcodingData, dataItem, masterName) {
        var parents, i, ln;

        if (dataItem.master === masterName) {
            return true;
        }

        parents = Ext.Array.filter(transcodingData, function (item) {
            return item.slave === dataItem.master;
        }, this);

        if (parents && parents.length) {
            for (i = 0, ln = parents.length; i < ln; i++) {
                if (this.hasMaster(transcodingData, parents[i], masterName)) {
                    return true;
                }
            }
        }

        return false;
    },

    /**
     * Карта зависимых классификаторов по таблицам
     *
     * @param {TranscodingDataItem[]} transcodingData
     * @param classifierName
     * @returns {Object} - key = table, value = slaves
     */
    getSlavesByTable: function (transcodingData, classifierName) {
        var slavesByTable = {};

        Ext.Array.each(transcodingData, function (dataItem) {
            var table = dataItem.table,
                master = dataItem.master,
                slave = dataItem.slave;

            if (classifierName && master !== classifierName) {
                return;
            }

            if (!slavesByTable[table]) {
                slavesByTable[table] = [];
            }

            slavesByTable[table].push(slave);
        });

        return slavesByTable;
    }

});
