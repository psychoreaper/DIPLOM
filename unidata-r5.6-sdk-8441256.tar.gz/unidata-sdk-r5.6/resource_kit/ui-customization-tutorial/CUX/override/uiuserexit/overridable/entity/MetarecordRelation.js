Ext.define('CUX.uiuserexit.overridable.entity.MetarecordRelation', {

    override: 'Unidata.uiuserexit.overridable.entity.MetarecordRelation',
    singleton: true,

    /**
     * Список доступных значений для поля displayName
     */
    availableDisplayNames: [],

    /**
     * Возвращает список доступных имен
     *
     * @param record {Object} - редактируемый справочник
     * @param selection {Object} - выбранная связь
     *
     * @return {array | undefined | false}
     */
    getAvailableDisplayNames: function (record, selection) { // jscs:ignore disallowUnusedParams
        return this.availableDisplayNames;
    },
});
