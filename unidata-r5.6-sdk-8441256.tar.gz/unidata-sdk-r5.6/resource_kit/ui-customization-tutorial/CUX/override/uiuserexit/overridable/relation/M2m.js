Ext.define('CUX.override.uiuserexit.overridable.relation.M2m', {

    override: 'Unidata.uiuserexit.overridable.relation.M2m',

    /**
     * Метод вызывается во время создания нового dataRelation
     *
     * @param metaRecord
     * @param dataRecord
     * @param metaRelation
     * @param dataRelation
     */
    onDataRelationCreated: function (metaRecord, dataRecord, metaRelation, dataRelation) { // jscs:ignore disallowUnusedParams
        
        var metaRecordName = metaRecord.get('name');
        var validFrom;
        var validTo;
        
        // устанавливаем периоды актуальности в зависимости от метамодели         
        switch (metaRecordName) {
            case 'metaRecordA':
               
               var validityPeriod = metaRecord.get('validityPeriod');
               validFrom = Unidata.util.ValidityPeriod.getMinDate(validityPeriod);
               validTo = Unidata.util.ValidityPeriod.getMaxDate(validityPeriod);
               
               break;
            default:
               validFrom = dataRecord.get('validFrom');
               validTo = dataRecord.get('validTo');
        }
         
        dataRelation.set('validFrom', validFrom);
        dataRelation.set('validTo', validTo);
    }

});
