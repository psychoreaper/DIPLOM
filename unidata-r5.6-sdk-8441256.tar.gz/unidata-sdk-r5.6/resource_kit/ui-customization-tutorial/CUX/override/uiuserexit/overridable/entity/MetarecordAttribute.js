Ext.define('CUX.uiuserexit.overridable.entity.MetarecordAttribute', {

    override: 'Unidata.uiuserexit.overridable.entity.MetarecordAttribute',
    singleton: true,

    /**
     * Список доступных значений для поля displayName
     */
    availableDisplayNames: [],

    /**
     * Возвращает список доступных имен
     *
     * @param context {Object} - контекст
     *
     * @return {array | undefined | false}
     */
    getAvailableDisplayNames: function (context) { // jscs:ignore disallowUnusedParams
        return this.availableDisplayNames;
    },
});
