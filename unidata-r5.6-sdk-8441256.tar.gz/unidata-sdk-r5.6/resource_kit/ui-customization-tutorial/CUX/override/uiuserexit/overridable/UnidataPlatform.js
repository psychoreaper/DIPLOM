Ext.define('CUX.override.uiuserexit.overridable.UnidataPlatform', {
    override: 'Unidata.uiuserexit.overridable.UnidataPlatform',

    platformFaviconUrl: 'http://www.catcorporation.local/favicon.png',
    platformTitle: 'Котики',

    getLogoPlatformHtml: function () {
        var locale = Unidata.Config.getLocale(),
            tpl,
            data;

        tpl = new Ext.XTemplate(
            '<div style="text-align: center">',
            '<img src="{url}" alt="Cat logo alt text"/>',
            '</div>'
        );

        data = {
            url: 'http://www.catcorporation.local/cat-corporation-logo.png'
        };

        return tpl.apply(data);
    },

    getMainMenuPlatformTextTpl: function () {
        var tpl;

        tpl = [
            '<img src="http://www.catcorporation.local/cat-corporation-menu-text.png" alt="Cat menu text alt text"/>'
        ];

        return tpl;
    },

    getMainMenuPlatformIconTpl: function () {
        var tpl;

        tpl = [
            '<span class="{iconCls}">',
            '<img src="http://www.catcorporation.local/cat-corporation-menu-logo.png" alt="Cat menu logo alt text"/>',
            '</span>'
        ];

        return tpl;
    }
});
