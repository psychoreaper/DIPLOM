Ext.define('CUX.override.uiuserexit.overridable.workflow.task.WorkflowTask', {

    override: 'Unidata.uiuserexit.overridable.workflow.task.WorkflowTask',
    singleton: true,

    /**
     * Массив элементов меню экрана "Задача"
     *
     * если массив пуст - меню не отображается
     *
     * каждый элемент должен содержать:
     * - text - отображаемый текст
     * - reference - идентификатор пункта меню
     * @returns []
     */
    taskDottedMenuItems: [
        {
          text: 'Скрыть меню',
          reference: 'hideMenuItem'
        }
    ],

    /**
     * Обработчик события клика по пункту меню
     *
     * @param menu {Object} - компонент меню
     * @param item {Object} - компонент пункта меню, по которому был совершен клик
     * @param event {Object} - событие
     *
     */
    handleMenuClick: function (menu, item, event) {
        if (item.reference === 'hideMenuItem') {
            this.menuPanel.setHidden(true);
        }
    }
});
