/**
 * user exit реализующий трансформацю отображения строковых атрибутов в результатх поиска
 * Части текста выделяются цветом, в зависимости от значения
 *
 * @author Aleksandr Bavin
 * @date 2019-09-26
 */
Ext.define('CUX.override.uiuserexit.overridable.search.SearchResult', {

    override: 'Unidata.uiuserexit.overridable.search.SearchResult',

    numColor: 'blue',
    latColor: 'green',

    /**
     * Метод для преобразования значений атрибутов в результатах поиска
     *
     * @param {Unidata.model.attribute.SimpleAttribute | Unidata.model.attribute.SimpleAttribute | Unidata.model.attribute.CodeAttribute} metaAttribute
     * @param {string[]} values
     * @returns {string[]} - необходимо вернуть массив преобразованных значений
     */
    transformResultValues: function (metaAttribute, values) {
        var me = this,
            type = metaAttribute.get('typeValue'),
            format = '<span style="color: {0}">{1}</span>';

        if (type === 'String') {
            Ext.Array.each(values, function (value, index, arr) {
                // подсвечиваем части текста цветом
                arr[index] = value.replace(/(\d+)|([A-Za-z]+)/g, function (match, num, lat) {
                    if (num) {
                        return Ext.String.format(format, me.numColor, match);
                    }

                    if (lat) {
                        return Ext.String.format(format, me.latColor, match);
                    }
                });
            });
        }

        return values;
    }

});
