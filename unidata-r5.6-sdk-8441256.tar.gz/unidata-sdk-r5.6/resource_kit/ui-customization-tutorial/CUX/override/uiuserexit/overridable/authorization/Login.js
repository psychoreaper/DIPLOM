Ext.define('CUX.override.uiuserexit.overridable.authorization.Login', {
    override: 'Unidata.uiuserexit.overridable.authorization.Login',

    backgroundCls: 'cat-login-background'
});
