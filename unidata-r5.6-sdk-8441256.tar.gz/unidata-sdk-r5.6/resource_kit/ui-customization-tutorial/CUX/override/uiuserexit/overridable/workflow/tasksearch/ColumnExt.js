/**
 * Точка расширения для модификации отображаемых результатов поиска задач
 *
 * @author Vladimir Stebunov
 * @date 2020-08-05
 */
Ext.define('Unidata.uiuserexit.overridable.workflow.tasksearch.ColumnExt', {

    singleton: true,

    /**
     * Метод для формирования колонок
     *
     * @param {Unidata.model[]} metaRecord - название поля пришедшее с сервера
     * @returns {Ext.grid.column.Column[]} - колонки
     */
    formColumnsBy: function (metaRecord, columns) {
        var me = this;

        myColumns = [
            {
                column_id: 'taskDescription',
                dataIndex: 'taskDescription',
                name: 'taskDescription',
                stateId: 'taskDescription',
                text:  Unidata.i18n.t('workflow>tasksearch.taskDescription')
            },
            {
                column_id: 'recordTitle',
                dataIndex: 'recordTitle',
                name: 'recordTitle',
                stateId: 'recordTitle',
                text: Unidata.i18n.t('workflow>tasksearch.recordName'),
                renderer: me.renderRecordTitle
            },
            {
                column_id: 'entityTypeTitle',
                dataIndex: 'entityTypeTitle',
                name: 'entityTypeTitle',
                stateId: 'entityTypeTitle',
                text:  Unidata.i18n.t('glossary:entity'),
                renderer: me.renderEntityTypeTitle
            },
            {
                column_id: 'createDate',
                dataIndex: 'createDate',
                name: 'createDate',
                stateId: 'createDate',
                text:  Unidata.i18n.t('workflow>tasksearch.createDate'),
                renderer: me.renderCreateDate
            },
            {
                column_id: 'taskAssignee',
                dataIndex: 'taskAssignee',
                name: 'taskAssignee',
                stateId: 'taskAssignee',
                text:  Unidata.i18n.t('workflow>tasksearch.taskAssignee')
            },
            {
                column_id: 'recordState',
                dataIndex: 'recordState',
                name: 'recordState',
                stateId: 'recordState',
                text: Unidata.i18n.t('workflow>tasksearch.recordState'),
                renderer: me.renderRecordState
            }
        ];

        return myColumns;
    },

    /*
    * Пример вывода
    */
    renderCreateDate: function (value) {
        return Ext.Date.format(value, Unidata.Config.getDateTimeFormatProxy());
    },

    renderEntityTypeTitle: function (value, metadata, task) {
        return task.getVariables().get('entityTypeTitle');
    },

    renderRecordTitle: function (value, metadata, task) {
        return task.getVariables().get('recordTitle');
    },

    renderRecordState: function (value) {
        var tpl = new Ext.XTemplate(
            '<span class="un-workflow-task-mainPanel">' +
            '<span class="un-workflow-task-record-state">' +
            '{value}' +
            '</span>' +
            '</span>',
            {
                compiled: true
            }),
            state =  Unidata.i18n.t('workflow>tasksearch.task.' + value.toLowerCase()),
            html = tpl.apply({value: state});

        return html;
    }

});
