Ext.define('CUX.override.uiuserexit.overridable.dataviewer.DataViewer', {
    override: 'Unidata.uiuserexit.dataviewer.DataViewer',
    singleton: true,

    /**
     * Реализует дополнительную логику перед удалением записи.
     * Для продолжения процесса удаления необходимо вызывать dataViewer.destroyEntity,
     * который принимает следующие параметры:
     * - dataViewer - required - Unidata.view.steward.dataentity.DataViewer
     * - skipPrompt - optional - boolean - пропустить окно подтверждения удаления
     * - message    - optional - string  - текст, отображающийся в окне удаления
     *
     *
     * @param {Unidata.view.steward.dataentity.DataViewer} dataViewer
     */
     onDestroy: function (dataViewer) {
        var skipPrompt = false;
        var customMessage = 'custom message';
         
        dataViewer.destroyEntity(dataViewer, skipPrompt, customMessage);
     }
});
