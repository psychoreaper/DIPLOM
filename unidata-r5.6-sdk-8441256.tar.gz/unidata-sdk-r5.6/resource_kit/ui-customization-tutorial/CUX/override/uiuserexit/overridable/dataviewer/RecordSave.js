Ext.define('CUX.override.uiuserexit.overridable.dataviewer.DataViewer', {
    override: 'Unidata.uiuserexit.dataviewer.DataViewer',
    singleton: true,

    /**
     * Реализует дополнительную логику перед сохранением записи.
     * Для продолжения процесса удаления необходимо вызывать dataViewer.saveAll
     *
     * @param {Unidata.view.steward.dataentity.DataViewer} dataViewer
     */
    onSave: function (dataViewer) {
        if (dataViewer.getDataRecord().get('createdBy') === 'admin') {
            Unidata.showError('Admin shall not pass!'); //если запись была создана пользователем admin, выводим ошибку, в другом случае -сохраняем
        } else {
            dataViewer.saveAll();
        }

    }

});
