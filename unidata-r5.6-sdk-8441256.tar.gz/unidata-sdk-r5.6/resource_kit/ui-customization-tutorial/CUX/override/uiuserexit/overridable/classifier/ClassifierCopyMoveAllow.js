﻿Ext.define('CUX.unidata.ClassifierCopyMoveAllow', {

    singleton: true,

    /**
     * Простой userexit запрещает переносить или копировать в элементы с 3 в имени
     *
     * @param classifierNode {Object} - узел классификатора
     * @param operationType {String} - тип операции
     *
     * @return {String 'DENY' | 'INHERITED_DENY' | 'ALLOW'}
     */
    getAllow: function (classifierNode, operationType) { // jscs:ignore disallowUnusedParams        
        return classifierNode.get('name').indexOf('3') === -1 ? 'ALLOW' : 'DENY';
    },
});
