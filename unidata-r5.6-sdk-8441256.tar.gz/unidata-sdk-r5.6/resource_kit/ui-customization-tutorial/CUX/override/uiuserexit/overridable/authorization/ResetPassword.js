Ext.define('CUX.override.uiuserexit.overridable.authorization.ResetPassword', {
    override: 'Unidata.uiuserexit.overridable.authorization.ResetPassword',

    backgroundCls: 'cat-login-background'
});
