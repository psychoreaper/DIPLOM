Ext.define('CUX.override.uiuserexit.overridable.authorization.InitialPage', {
    override: 'Unidata.uiuserexit.overridable.authorization.InitialPage',

    /**
     * Функция, задающая hash для переадресации пользователя на другую страницу при логине
     *
     * @param authenticateData {Object}
     *
     * @return {string} Пример - #main?section=data
     */
    buildInitialPageHash: function (authenticateData) {
        return '#main?section=data'
    }
});
