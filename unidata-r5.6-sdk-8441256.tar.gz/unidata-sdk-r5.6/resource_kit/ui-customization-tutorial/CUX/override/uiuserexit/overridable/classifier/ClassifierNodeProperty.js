Ext.define('CUX.uiuserexit.overridable.classifier.ClassifierNodeProperty', {

    override: 'Unidata.uiuserexit.overridable.classifier.ClassifierNodeProperty',
    singleton: true,

    /**
     * Список доступных значений для поля displayName
     */
    availableDisplayNames: [],

    /**
     * Возвращает список доступных имен
     *
     * @param classifier {Object} - классификатор
     * @param classifierNode {Object} - узел классификатора
     *
     * @return {array | undefined | false}
     */
    getAvailableDisplayNames: function (classifier, classifierNode) { // jscs:ignore disallowUnusedParams
        return this.availableDisplayNames;
    },
});
