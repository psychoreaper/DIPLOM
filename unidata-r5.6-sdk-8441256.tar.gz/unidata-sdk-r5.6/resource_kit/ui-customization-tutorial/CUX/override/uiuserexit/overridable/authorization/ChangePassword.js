Ext.define('CUX.override.uiuserexit.overridable.authorization.ChangePassword', {
    override: 'Unidata.uiuserexit.overridable.authorization.ChangePassword',

    backgroundCls: 'cat-login-background'
});
