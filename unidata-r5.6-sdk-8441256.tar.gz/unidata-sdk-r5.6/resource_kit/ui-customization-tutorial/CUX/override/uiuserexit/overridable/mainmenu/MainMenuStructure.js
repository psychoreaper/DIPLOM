Ext.define('CUX.override.uiuserexit.overridable.mainmenu.MainMenuStructure', {
    override: 'Unidata.uiuserexit.overridable.mainmenu.MainMenuStructure',

    requires: [
        'CUX.mainmenu.Caaaaaaaaaat'
    ],

    /**
     * @typedef {Object} ListItem
     * @property {string} text - название, отображаемое в меню
     * @property {string} reference - уникальный идентификатор, используется в роутинге
     * @property {string} view - alias компонента, который будет открыт в рабочей области
     * @property {string} iconCls - css класс иконки
     * @property {boolean} pinned - отмеченные элементы меню
     */

    /**
     * Обработка данных
     * @see Unidata.view.main.menu.MainMenuStructure.getDataProcessingList
     *
     * @param {ListItem[]} dataProcessingListItems
     */
    editDataProcessingListItems: function (dataProcessingListItems) {

        // добавляем новый элемент в начало списка
        dataProcessingListItems.unshift({
            text:      'Поиграй с котиком',
            reference: 'caaaaaaaaaat',
            view:      'caaaaaaaaaat',
            iconCls:   'icon-heart',
            pinned: true
        });
    }
});
