Ext.define('CUX.override.uiuserexit.overridable.workflow.tasksearch.Resultset', {
    override: 'Unidata.uiuserexit.overridable.workflow.tasksearch.Resultset',

    singleton: true,

    /**
     * Скрываем имя реестра и дату назначения задачи
     */
    taskHiddenAttributes: ['entityTypeTitle', 'createDate '],

    /**
     * Скрыыем имя записи для процессов
     */
    processHiddenAttributes: ['recordTitle']
});
