Ext.define('CUX.override.uiuserexit.overridable.security.PasswordPolicy', {
    override: 'Unidata.uiuserexit.overridable.security.PasswordPolicy',

    isPasswordSecuredDefault: function (password) {
        var secured = false,
            regExp = /^(?=[0-9qweQWE#$&]{10,}$)(?=.*?[qwe])(?=.*?[QWE])(?=.*?\d)(?=.*?[#$&]).*/;

        if (regExp.test(password)) {
            secured = true;
        }

        return secured;
    },

    getUnsecuredMessageDefault: function (password) {
        var msg = 'Пароль не безопасен! Разрешенные символы: qweQWE#$&0123456789. Минимальная длина 10 символов.';

        return msg;
    }
});
