Ext.define('CUX.override.uiuserexit.overridable.dataviewer.DataViewer', {
    override: 'Unidata.uiuserexit.dataviewer.DataViewer',

    singleton: true,

    /**
     * Добавляет комментарий к таймлайну периода валидации
     *
     *
     * @param {Unidata.model.data.Record} dataRecord
     * @param {Object} values - параметры периода актуальности,
     * @param {string} dateFrom - начальная дата периода,
     * @param {string} dateTo - конечная дата периода,
     * @param {boolean} selected - true если данный период выбран.
     * @returns {string | null}
     */
    validationPeriodNote: function (dataRecord, values, dateFrom, dateTo, selected) {
        if (selected) {
            return 'selected';
        }
    }
});
