Ext.define('CUX.uiuserexit.overridable.classifier.ClassifierEditor', {

    override: 'Unidata.uiuserexit.overridable.classifier.ClassifierEditor',
    singleton: true,

    /**
     * Список доступных значений для поля displayName
     */
    availableDisplayNames: [],

    /**
     * Возвращает список доступных имен
     *
     * @param classifier {Object} - классификатор
     *
     * @return {array | undefined | false}
     */
    getAvailableDisplayNames: function (classifier) { // jscs:ignore disallowUnusedParams
        return this.availableDisplayNames;
    },
});
