Ext.define('CUX.override.uiuserexit.overridable.dataviewer.DataViewer', {
    override: 'Unidata.uiuserexit.dataviewer.DataViewer',
    singleton: true,

    /**
     * Реализует дополнительную логику перед удалением периода актуальности.
     * Для продолжения процесса удаления необходимо вызывать dataCard.destroyTimeInterval
     * который принимает следующие параметры:
     * - timeIntervalViewer - required - Unidata.view.component.timeinterval.TimeIntervalDataView
     * - etalonId   - required - number
     * - skipPrompt - optional - boolean - пропустить окно подтверждения удаления
     *
     *
     * @param {Unidata.view.steward.dataviewer.card.data.DataCard} dataCard
     * @param {Unidata.view.component.timeinterval.TimeIntervalDataView} timeIntervalViewer
     * @param {string} etalonId
     */
    onValidatyPeriodDestroy: function (dataCard, timeIntervalViewer, etalonId) {
        dataCard.destroyTimeInterval(timeIntervalViewer, etalonId);
    }
});
