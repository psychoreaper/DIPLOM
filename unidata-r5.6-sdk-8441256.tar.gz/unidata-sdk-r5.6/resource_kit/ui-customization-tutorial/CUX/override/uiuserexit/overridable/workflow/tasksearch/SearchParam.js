/**
 * Реализация функции для показа дополнительных полей и их кастомизации
 *
 * @author Vladimir Stebunov
 * @date 2020-03-16
 */
Ext.define('Unidata.uiuserexit.overridable.workflow.tasksearch.SearchParam', {
    singleton: true,

    /*
     * Дополнительные параметры для поиска и отображения
     * пример структуры для вывода
     */
    searchParam: [
        {
            displayName: 'Инициатор',
            name: 'initiatorName',
            element: new Ext.form.TextField({
                xtype: 'textfield',
                name: 'initiatorName',
                ui: 'un-field-default',
                labelAlign: 'top',
                fieldLabel: 'Инициатор',
                flex: 1,
                margin: '0 0 3 0',
                triggers: {
                    clear: {
                        cls: 'x-form-clear-trigger',
                        handler: function () {
                            this.setValue('');
                        }
                    }
                }
            })
        }
    ],

    /**
     * Виджеты для поисковой выдачи задач
     *
     * @returns []
     */
    getControls: function () {
        return Ext.Array.map(this.searchParam, function (param) {
            return param.element;
        });
    },

    /**
     * Имена параметров для поиска должны совпадать с сервером
     *
     * @returns [string]
     */
    getVariableNames: function () {
        return Ext.Array.map(this.searchParam, function (param) {
            return param.name;
        });
    },

    /**
     * Параметры для вывода в результате
     *
     * @return [{displayName, name}]
     */
    getOutput: function () {
        return Ext.Array.map(this.searchParam, function (param) {
            return {
                name: param.name,
                displayName: param.displayName
            };
        });
    }

});
