Ext.define('CUX.uiuserexit.overridable.classifier.ClassifierAttributeProperty', {

    override: 'Unidata.uiuserexit.overridable.classifier.ClassifierAttributeProperty',
    singleton: true,

    /**
     * Список доступных значений для поля displayName
     */
    availableDisplayNames: [],

    /**
     * Возвращает список доступных имен
     *
     * @param classifierNode {Object} - узел классификатора
     * @param attributeNode {Object} - атрибут
     *
     * @return {array | undefined | false}
     */
    getAvailableDisplayNames: function (classifierNode, attributeNode) { // jscs:ignore disallowUnusedParams
        return this.availableDisplayNames;
    },
});
