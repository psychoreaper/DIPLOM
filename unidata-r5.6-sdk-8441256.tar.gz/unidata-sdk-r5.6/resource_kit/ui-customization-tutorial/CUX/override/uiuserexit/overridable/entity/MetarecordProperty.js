Ext.define('CUX.uiuserexit.overridable.entity.MetarecordProperty', {

    override: 'Unidata.uiuserexit.overridable.entity.MetarecordProperty',
    singleton: true,

    /**
     * Список доступных значений для поля displayName
     */
    availableDisplayNames: [],

    /**
     * Возвращает список доступных имен
     *
     * @param record {Object} - редактируемый справочник
     *
     * @return {array | undefined | false}
     */
    getAvailableDisplayNames: function (record) { // jscs:ignore disallowUnusedParams
        return this.availableDisplayNames;
    },
});
