Ext.define('CUX.override.uiuserexit.overridable.search.RecordShow', {

    override: 'Unidata.uiuserexit.overridable.search.RecordShow',
    singleton: true,

    /**
     * Вызывается при рендере кнопки "Создать новую запись"
     *
     * возвращает объект с кастомными параметрами кнопки.
     *
     * @return {Object | undefined}
     * - hide - boolean - если значение - true - кнопка будет скрыта
     * 
     * Параметры для изменения содержимого кнопки:
     * 
     * - text - текст
     * - tooltip - тултип
     * - iconCls - класс иконки - если значение - '' - иконка будет скрыта
     *
     * Параметры для точного позиционирования кнопки:
     *
     * - left - number
     * - width - number 
     * - marginRight - number
     */

    getCreateDataRecordButtonConfig: function () { // jscs:ignore disallowUnusedParams
        return {
            text: 'Создать новую запись',
            iconClass: '',
            left: 10,
            width: 190,
            marginRight: 160
        }
    },
});
