Ext.define('CUX.override.uiuserexit.dataviewer.DataViewer', {
    override: 'Unidata.uiuserexit.dataviewer.DataViewer',

    onSave: function (dataViewer) {
        if (dataViewer.getDataRecord().get('createdBy') === 'admin') {
            Unidata.showError('Admin shall not pass!'); //если запись была создана пользователем admin, выводим ошибку, в другом случае -сохраняем
        } else {
            dataViewer.saveAll();
        }

    }

});
