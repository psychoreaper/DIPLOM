Ext.define('CUX.yamap.YandexMapInput', {
    extend: 'Ext.form.field.Base',

    childEls: [
        'containerHolder'
    ],

    referenceHolder: true,

    fieldsContainer: null,
    externalInput: null,
    externalMapContainer: null,
    yandexMap: null,
    yandexMapSearchControl: null,
    addressMasterWrap: null,

    externalInputCfg: null,

    fieldSubTpl: '<div id="{cmpId}-containerHolder" data-ref="containerHolder"></div>',

    msgTarget: 'under',
    combineErrors: true,

    readOnly: false,
    allowBlank: false,

    config: {
        labelText: null
    },

    initComponent: function () {
        this.externalInputCfg = this.externalInputCfg || {};
        this.buildFieldsContainer();
        this.buildFields();

        this.callParent(arguments);

        this.externalInput.on('render', this.onExternalInputFieldRender, this);
    },

    buildFieldsContainer: function () {
        this.fieldsContainer = Ext.create('Ext.container.Container', {
            referenceHolder: true,
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            items: [
            ]
        });
    },

    buildFields: function () {
        this.createExternalInputField();
        this.createExternalMapField();
        this.createAddressMasterWrap();

        this.addressMasterWrap.addressMasterContainer.add(this.externalInput);
        this.fieldsContainer.add(this.addressMasterWrap);
        this.fieldsContainer.add(this.externalMapContainer);
    },

    addressStrIntoObj: function(address) {
        var metadata = {
            'бул': 'Бульвар',
            'г': 'Город',
            'дер': 'Деревня',
            'кр': 'Край',
            'обл': 'Область',
            'окр': 'Городской Округ',
            'пос': 'Посёлок',
            'р-н': 'Район',
            'рес': 'Республика',
            'ул': 'Улица'
        };

        address.nameByType = {};

        if (address.ADDRESS_INFO) {
            var addressStr = "";

            for (var key in address.ADDRESS_INFO) {
                var item = address.ADDRESS_INFO[key];

                item.elementName = metadata[item.elementTypeName] ? metadata[item.elementTypeName] : item.elementTypeName;

                var addressNameStr = item.elementTypeName + ". " + item.formalName;

                addressStr += (addressStr.length == 0) ? (addressNameStr) : (", " + addressNameStr);

                address.nameByType[item.elementTypeName] = item.formalName;
            }
            var houseInfo = address.HOUSE_INFO;

            if (houseInfo) {
                addressStr += houseInfo.HOUSE_NUMBER ? ", дом " + houseInfo.HOUSE_NUMBER : "";
                addressStr += houseInfo.BUILDING_NUMBER ? ", корпус " + houseInfo.BUILDING_NUMBER : "";
                addressStr += houseInfo.STRUCTURE ? ", " + houseInfo.STRUCTURE.STRUCTURE_STATUS.STRUCTURE_STATUS_SHORT_DESC + " " + houseInfo.STRUCTURE.STRUCTURE_NUM : "";
            }
            address.ADDRESS_STR = addressStr;
        }
        return address;
    },

    createAddressMasterWrap: function () {
        var me = this,
            cfg,
            labelText = this.getLabelText();

        cfg = {
            xtype: 'container',
            referenceHolder: true,
            margin: '0 0',
            layout: {
                type: 'hbox',
                align: 'stretch'
            },
            items: [
                {
                    xtype: 'label',
                    cls: 'un-dataentity-attribute-title-text',
                    text: labelText,
                    hidden: labelText === null,
                    width: 92,
                    margin: '0 5 0 0'
                },
                {
                    xtype: 'container',
                    reference: 'addressMasterContainer',
                    layout: 'fit',
                    margin: '0 0 0 0',
                    flex: 1
                },
                {
                    xtype: 'button',
                    reference: 'showMapButton',
                    text: 'На карте',
                    height: 20,
                    padding: '0 5',
                    handler: function () {
                        var value = me.getValue();

                        if (me.externalMapContainer.isVisible()) {
                            me.externalMapContainer.hide();
                        } else {
                            me.externalMapContainer.show();

                            me.doYandexMapSearch(value);
                        }

                        me.updateLayout();

                        me.fireEvent('showonmap');
                    }
                }
            ]
        };

        this.addressMasterWrap = Ext.widget(cfg);

        this.addressMasterWrap.addressMasterContainer = this.addressMasterWrap.lookupReference('addressMasterContainer');
        this.addressMasterWrap.showMapButton = this.addressMasterWrap.lookupReference('showMapButton');
    },

    doYandexMapSearch: function (value) {
        var me = this;

        if (me.yandexMap) {
            me.yandexMap.controls.get('SearchControl');

            if (!Ext.isEmpty(value)) {
                me.yandexMapSearchControl.search(value);
            }
        }
    },

    createExternalMapField: function () {
        var me = this,
            cfg;

        cfg = {
            xtype: 'container',
            flex: 1,
            layout: 'fit',
            height: 400,
            margin: '10 0 0 0',
            hidden: true,
            listeners: {
                render: function (component) {
                    var mapContainerId = component.getId();

                    ymaps.ready(function () {
                        var searchControl;

                        me.yandexMap = new ymaps.Map(mapContainerId, {
                            center: [59.960297, 30.279854],
                            zoom: 17,
                            controls: ['zoomControl']
                        }, {
                            suppressObsoleteBrowserNotifier: true,
                            suppressMapOpenBlock: true
                        });

                        searchControl = new ymaps.control.SearchControl({
                            key: 'searchControl',
                            options: {
                                provider: 'yandex#search',
                                suppressYandexSearch: true
                            }
                        });

                        me.yandexMap.controls.add(searchControl);

                        me.yandexMapSearchControl = searchControl;
                    });
                },
                resize: function () {
                    if (me.yandexMap) {
                        me.yandexMap.container.fitToViewport();
                    }
                }
            }
        };

        this.externalMapContainer = Ext.widget(cfg);
    },

    createExternalInputField: function () {
        var me = this,
            cfg;

        cfg = {
            xtype: 'combobox',
            flex: 1,
            listeners: {
                errorchange: this.onComponentFieldErrorChange.bind(this)
            },
            displayField: 'full_address',
            valueField: 'address_id',
            queryParam: 'term',
            queryMode: 'remote',
            minChars: 0,
            autoLoadOnValue: false,
            store: {
                fields: [
                    {
                        name: 'address_id',
                        type: 'string'
                    },
                    {
                        name: 'full_address',
                        type: 'string'
                    }
                ],
                proxy: {
                    url: 'http://www.addressmaster.ru/AutoCompleteServlet',
                    type: 'ajax',
                    timeout: Ext.Ajax.timeout,
                    headers: {
                        'Content-Type': 'application/json;charset=utf-8'
                    },
                    reader: {
                        type: 'json',
                        rootProperty: 'addressList',
                        transform: {
                            fn: function (data) {
                                var result = {addressList: []};

                                if (data.addressList) {
                                    Ext.each(data.addressList, function (it) {
                                        var address = me.addressStrIntoObj (it);

                                        result.addressList.push({
                                            address_id: address.ADDRESS_ID,
                                            full_address: address.ZIPCODE + ', ' + address.ADDRESS_STR,
                                            post: address.ZIPCODE,
                                            city: address.nameByType['город'] || ''
                                        });
                                    });
                                }

                                return result;
                            }
                        }
                    }
                }
            },
            triggers: {
                reset: {
                    cls: 'x-form-clear-trigger',
                    handler: function () {
                        me.resetValue();
                    }
                }
            }
        };

        cfg = Ext.apply(cfg, this.externalInputCfg);

        this.externalInput = Ext.widget(cfg);

        this.externalInput.on('select', this.onExternalInputFieldChange, this);
    },

    onExternalInputFieldChange: function (field, record) {
        var record = field.getSelection(),
            data = record.getData(),
            oldValue,
            value;

        oldValue = this.getValue();
        value = data.full_address;

        this.value = value;

        if (this.externalMapContainer && this.externalMapContainer.isVisible()) {
            this.doYandexMapSearch(value);
        }

        this.fireEvent('change', this, value, oldValue);
        this.fireEvent('externalinputchange', this, data);
    },

    resetValue: function () {
        var oldValue,
            value;

        value = '';
        oldValue = this.value;

        this.value = value;
        this.externalInput.reset();

        this.yandexMapSearchControl.clear();

        this.fireEvent('change', this, value, oldValue);
        this.fireEvent('externalinputchange', this, {});
    },

    onRender: function () {
        this.callParent(arguments);

        this.fieldsContainer.render(this.containerHolder);

        this.updateLayoutFieldsContainer();
    },

    onResize: function () {
        this.callParent(arguments);

        this.updateLayoutFieldsContainer();
    },

    updateLayoutFieldsContainer: function () {
        if (this.fieldsContainer.rendered) {
            this.fieldsContainer.updateLayout();
        }
    },

    onExternalInputFieldRender: function () {
        this.updateLayoutFieldsContainer();
    },

    updateLayout: function () {
        this.callParent(arguments);

        this.updateLayoutFieldsContainer();
    },

    getValue: function () {
        return this.value;
    },

    setValue: function (value) {
        var idGen = new Ext.data.identifier.Uuid(),
            data,
            externalInput;

        this.value = value;

        externalInput = this.externalInput;

        data = {
            address_id: idGen.generate(),
            full_address: value
        };

        externalInput.getStore().add(data);

        externalInput.setValue(data.address_id);
    },

    onComponentFieldErrorChange: function () {
        var errors = this.getComponentFieldsErrors();

        if (errors) {
            this.markInvalid(errors);
        } else {
            this.clearInvalid();
        }

        this.wasValid = null;
        this.validate();
    },

    getComponentFieldsErrors: function () {
        var errors;

        errors = Ext.Array.merge(
            this.getComponentFieldErrors(this.externalInput)
        );

        return Ext.Array.unique(errors);
    },

    getComponentFieldErrors: function (field) {
        return field.getActiveErrors();
    },

    setReadOnly: function (readOnly) {
        this.readOnly = readOnly;

        this.externalInput.setReadOnly(readOnly);
    },

    setDisabled: function (value) {
        this.externalInput.setDisabled(value);

        this.callParent(arguments);
    },

    isValid: function () {
        var errors = this.getComponentFieldsErrors(),
            valid = !Boolean(errors.length);

        if (!this.externalInput.isValid()) {
            valid = false;
        }

        return valid;
    }
});
