Ext.define('CUX.yamap.YandexMapExternalAttribute', {
    extend: 'Unidata.view.steward.dataentity.attribute.AbstractAttribute',

    requires: [],

    statics: {
        TYPE: 'String'
    },

    inputVisible: true,
    hideAttributeTitle: true,

    constructor: function () {
        this.hideAttributeTitle = true;
        this.callParent(arguments);
    },

    initInput: function () {
        var input,
            displayName;

        displayName = this.getMetaAttributeField('displayName');

        input = Ext.create('CUX.yamap.YandexMapInput', {
            xtype: 'textfield',
            allowBlank: this.getMetaAttributeField('nullable'),
            msgTarget: 'under',
            width: this.inputWidth,
            maxWidth: this.maxInputWidth,
            preventMark: this.getPreventMarkField(),
            renderTo: this.elInputCont,
            labelText: displayName
        });

        input.on('externalinputchange', this.onExternalInputChange, this);

        input.on('resize', function () {
            alert();
        }, this);

        input.on('showonmap', function () {
            this.updateLayout();
        }, this);

        return input;
    },

    onExternalInputChange: function (field, data) {
        this.fireEvent('externalinputchange', {
            'City': data.city,
            'PostIndex': data.post
        });
    }
});
