Ext.define('CUX.yamap.YandexMapExternalAttributeResolver', {
    extend: 'Unidata.view.steward.dataentity.ExternalAttributeResolverBase',

    statics: {
        active: true,

        resolveClassConstructor: function (metaRecord, dataRecord, metaAttribute, dataAttribute, opts) {
            if (metaRecord && metaRecord.get('name') === 'YANDEXMAP') {
                if (metaAttribute && metaAttribute.get('name') === 'FullAddress') {
                    return Ext.ClassManager.get('CUX.yamap.YandexMapExternalAttribute');
                }
            }

            return null;
        }
    }
});
