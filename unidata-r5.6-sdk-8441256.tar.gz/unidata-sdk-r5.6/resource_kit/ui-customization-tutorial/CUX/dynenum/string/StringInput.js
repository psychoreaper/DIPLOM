/**
 * Демонстрационный пример реализации контрола для выбора значения из справочника или реестра.
 * Реализация для строкового атрибута
 */

Ext.define('CUX.dynenum.string.StringInput', {
    extend: 'Ext.form.field.Base',

    childEls: [
        'containerHolder'
    ],

    referenceHolder: true,

    fieldsContainer: null,
    externalInput: null,

    externalInputCfg: null,

    fieldSubTpl: '<div id="{cmpId}-containerHolder" data-ref="containerHolder"></div>',

    combineErrors: true,

    readOnly: false,
    allowBlank: false,

    entityName: null,
    entityType: null, // допустимые значения 'entity' и 'lookupentity'

    dedAttribute: null,

    config: {
        displayValue: null
    },

    initComponent: function () {
        this.externalInputCfg = this.externalInputCfg || {};

        this.buildFieldsContainer();
        this.buildFields();

        this.callParent(arguments);

        this.relayEvents(this.externalInput, [
            'focus',
            'blur'
        ]);

        this.externalInput.on('render', this.onExternalInputFieldRender, this, {single: true});
    },

    onRender: function () {
        var displayValue = this.getDisplayValue();

        this.callParent(arguments);

        this.fieldsContainer.render(this.containerHolder);

        if (!Ext.isEmpty(displayValue)) {
            this.externalInput.setValueSilent(displayValue);
            this.externalInput.setDisplayValue(displayValue);
        }

        this.updateLayoutFieldsContainer();
    },

    onExternalInputFieldRender: function () {
        this.updateLayoutFieldsContainer();
    },

    onResize: function () {
        this.callParent(arguments);

        this.updateLayoutFieldsContainer();
    },

    onDestroy: function () {
        this.dedAttribute = null;

        this.callParent(arguments);
    },

    buildFieldsContainer: function () {
        this.fieldsContainer = Ext.create('Ext.container.Container', {
            referenceHolder: true,
            layout: {
                type: 'hbox',
                align: 'stretch'
            },
            items: []
        });
    },

    buildFields: function () {
        this.createExternalInputField();

        this.fieldsContainer.add(this.externalInput);
    },

    updateDisplayValue: function (value) {
        if (this.externalInput && this.externalInput.rendered) {
            this.externalInput.setValueSilent(value);
            this.externalInput.setDisplayValue(value);
        }
    },

    createExternalInputField: function () {
        var me = this,
            cfg;

        cfg = {
            xtype: 'dropdownpickerfield',
            reference: 'pickerField',
            flex: 1,
            openLookupRecordHidden: true,
            expandTriggerHidden: false,
            etalonId: 'fake',
            hideClearTrigger: false,

            entityType: this.entityType,
            entityName: this.entityName,

            displayAttributes: ['value'], // перечисляем атрибуты, которые мы хотим отображать, можно указать null тогда атрибуты будут взяты из метамодели
            searchAttributes: ['value'],  // перечисляем атрибуты, по которым мы хотим искать, можно указать null тогда атрибуты будут взяты из метамодели

            publishes: ['rawValue'],
            allowBlank: this.dedAttribute.getMetaAttributeField('nullable'),
            msgTarget: 'none',
            listeners: {
                errorchange: this.onComponentFieldErrorChange
            }
        };

        this.externalInput = Ext.widget(cfg);
    },

    updateLayoutFieldsContainer: function () {
        if (this.fieldsContainer.rendered) {
            this.fieldsContainer.updateLayout();
        }
    },

    updateLayout: function () {
        this.callParent(arguments);

        this.updateLayoutFieldsContainer();
    },

    onComponentFieldErrorChange: function () {
        this.validateValue();
    },

    getComponentFieldsErrors: function () {
        var errors;

        errors = Ext.Array.merge(
            this.getComponentFieldErrors(this.externalInput)
        );

        return Ext.Array.unique(errors);
    },

    getComponentFieldErrors: function (field) {
        return field.getErrors();
    },

    setReadOnly: function (readOnly) {
        this.readOnly = readOnly;

        this.externalInput.setReadOnly(readOnly);
    },

    setDisabled: function (value) {
        this.externalInput.setDisabled(value);

        this.callParent(arguments);
    },

    isValid: function () {
        var errors = this.getComponentFieldsErrors(),
            valid = !Boolean(errors.length);

        if (!this.externalInput.isValid()) {
            valid = false;
        }

        this.validateValue();

        return valid;
    },

    validateValue: function () {
        var me = this,
            errors = me.getComponentFieldsErrors(),
            isValid = Ext.isEmpty(errors);

        if (!me.preventMark) {
            if (isValid) {
                me.clearInvalid();
            } else {
                me.markInvalid(errors);
            }
        }

        return isValid;
    },

    focus: function () {
        if (this.externalInput) {
            this.externalInput.focus.apply(this.externalInput, arguments);
        }
    }
});
