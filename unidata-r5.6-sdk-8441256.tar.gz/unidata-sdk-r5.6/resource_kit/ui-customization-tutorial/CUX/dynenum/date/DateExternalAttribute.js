/**
 * Демонстрационный пример реализации атрибута с типом Date для DataEntity.
 * Указания значения производится из списка допустимых значений, которые указываются в другом реестре.
 */

Ext.define('CUX.dynenum.date.DateExternalAttribute', {
    extend: 'Unidata.view.steward.dataentity.attribute.AbstractAttribute',

    requires: [
        'CUX.dynenum.date.DateInput' // зависимость, компонент данного класса пораждается в методе initInput
    ],

    statics: {
        TYPE: 'String',
        /**
         * строковый идентификатор, по данному идентификатору
         * определяетя можно ли применить внешнее представление или нет
         * идентификатор необходимо указать в customproperty для атрибута
         */
        CuxPresentationName: 'CUXDate'
    },

    /**
     * метод возвращает представление компонента для взаимодействия с пользователем.
     * вызывается DataEntity.
     *
     * @returns {CUX.dynenum.string.StringInput}
     */
    initInput: function () {
        var input;

        input = Ext.create('CUX.dynenum.date.DateInput', {
            xtype: 'textfield',
            allowBlank: this.getMetaAttributeField('nullable'),
            cls: 'un-lookup-attribute-picker-field',
            msgTarget: this.elError.getId(),
            width: this.inputWidth,
            displayValue: this.value,
            preventMark: this.getPreventMarkField(),
            renderTo: this.elInputCont,
            dedAttribute: this,
            entityName: 'DynEnumEntity_Date', // имя реестра или справочника из которого необходимо брать значения
            entityType: 'entity' // указываем с чем связан атрибут с реестром 'entity' или справочником 'lookupentity'
        });

        return input;
    },

    /**
     * возвращает объект с описанием обработчиков
     *
     * @returns {*}
     */
    setupInputEventsListening: function () {
        var listenerRemovers = this.callParent(arguments),
            remover;

        remover = this.input.externalInput.on({
            destroyable: true,
            scope: this,
            select: this.onChange,
            changecodevalue: this.onChange
        });

        listenerRemovers.push(remover);

        return listenerRemovers;
    },

    /**
     * устанавливает значение в инпут.
     * вызывается DataEntity.
     *
     * @param value
     */
    setInputValue: function (value) {
        var formatMills = Unidata.Config.getDateTimeFormatProxy(),
            formatDate = Unidata.Config.getDateFormat(),
            date;

        // приводим данные к нужному формату
        if (this.input) {
            date = Ext.Date.parse(value, formatMills);

            if (date) {
                this.input.setDisplayValue(Ext.Date.format(date, formatDate));
            }
        }
    },

    /**
     * возвращает значение выбраное пользователем.
     * вызывается DataEntity.
     *
     * @param value
     */
    getInputValue: function () {
        var formatMills = Unidata.Config.getDateTimeFormatProxy(),
            formatDate = Unidata.Config.getDateFormat(),
            date,
            text;

        // приводим данные к нужному формату
        if (this.input) {
            text = this.input.externalInput.getDisplayValue();
            date = Ext.Date.parse(text, formatDate);

            return Ext.Date.format(date, formatMills);
        }

        return false;
    }
});
