Ext.define('CUX.StartupLogger', {}, function () {
    console.log('Время запуска приложения: ', new Date());
});
