Ext.define('CUX.AjaxTimeout', {}, function () {
    var timeout = 24 * 60 * 60 * 1000;

    Ext.Ajax.setTimeout(timeout);
    Ext.override(Ext.data.proxy.Ajax, {timeout: timeout});
});
