Ext.define('CUX.CustomerExternalCss', {}, function () {
    var head = document.head || document.getElementsByTagName('head')[0],
        link = document.createElement('link');

    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = 'http://www.catcorporation.local/catstyle.css';

    head.appendChild(link);
});
