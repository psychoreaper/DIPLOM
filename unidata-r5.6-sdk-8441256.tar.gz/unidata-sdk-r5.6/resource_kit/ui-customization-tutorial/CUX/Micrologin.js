Unidata = Unidata || {};

Unidata.Micrologin = Unidata.Micrologin || {};

 Unidata.Micrologin.initCustomization = function () {
     // можно динамически создать css или script
     var head = document.head || document.getElementsByTagName('head')[0],
         link = document.createElement('link');

     link.type = 'text/css';
     link.rel = 'stylesheet';
     link.href = 'http://www.catcorporation.local/catstyle.css';

     head.appendChild(link);
 };

 Unidata.Micrologin.getLogoTpl = function () {
     var html;

     html = '<div style="text-align: center"> <img src="http://www.catcorporation.local/cat-corporation-logo.png" alt="Platform logo"></div>';

     return html;
 };

 Unidata.Micrologin.getBackgroundCls = function () {
     return 'cat-login-background';
 };

Unidata.Micrologin.transformResourceBundle = function (language, namespace, data) {
    if (language == "ru" && namespace == "common") {
        data.dashboard.currentState = "Общая статистика";
    }

    if (language == "ru" && namespace == "default") {
        data.search["query.title"] = "Поиск записей";
        data.search["query.title"] = "Искать записи";
    }

    return data;
};

 Unidata.Micrologin.platformFaviconUrl = 'http://www.catcorporation.local/favicon.png';
 Unidata.Micrologin.platformTitle = 'Котики';
